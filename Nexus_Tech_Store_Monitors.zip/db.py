"""
Database layer for NEXUS TECH STORE.

Talks to the MySQL/MariaDB database created by nexus_tech_store.sql, via XAMPP.

Install:  pip install mysql-connector-python
Setup:    Start Apache + MySQL in the XAMPP Control Panel, then import
          nexus_tech_store.sql once in phpMyAdmin (http://localhost/phpmyadmin).
"""

import hashlib

import mysql.connector
from mysql.connector import Error as MySQLError

# XAMPP defaults: host localhost, port 3306, user root, empty password.
# Change these if your setup differs (e.g. you set a MySQL root password).
DB_CONFIG = dict(
    host="localhost",
    port=3306,
    user="root",
    password="",
    database="nexus_tech_store",
)


# ---------------- Monitors & Accessories ----------------
# Categories whose products have an extra row in monitor_specs / monitor_accessory_specs.
MONITOR_CATEGORIES = {"Monitors"}
ACCESSORY_CATEGORIES = {"Monitor Arms", "Display Cables", "Webcams & Lights"}

SPEC_TABLES = {"monitor": "monitor_specs", "accessory": "monitor_accessory_specs"}

PANEL_TYPES = ["IPS", "VA", "TN", "OLED", "QD-OLED", "Mini-LED", "Other"]
ACCESSORY_TYPES = ["arm", "stand", "cable", "adapter", "webcam", "light_bar", "other"]

# (column, label, type, required, choices-or-default)
#   type: text | int | float | bool | choice | resolution | ratio
SPEC_FIELDS = {
    "monitor": [
        ("screen_size_in",   "Screen size (inches)",          "float",      True,  ""),
        ("resolution",       "Resolution (e.g. 2560x1440)",   "resolution", True,  ""),
        ("panel_type",       "Panel type",                    "choice",     True,  PANEL_TYPES),
        ("refresh_rate_hz",  "Refresh rate (Hz)",             "int",        True,  "60"),
        ("response_time_ms", "Response time (ms)",            "float",      False, ""),
        ("aspect_ratio",     "Aspect ratio (e.g. 16:9)",      "ratio",      True,  "16:9"),
        ("is_curved",        "Curved screen",                 "bool",       False, ""),
        ("hdr_support",      "HDR support (optional)",        "text",       False, ""),
        ("ports",            "Ports (optional)",              "text",       False, ""),
    ],
    "accessory": [
        ("accessory_type",   "Accessory type",                "choice",     True,  ACCESSORY_TYPES),
        ("compatibility",    "Compatibility (optional)",      "text",       False, ""),
        ("connector_type",   "Connector (optional)",          "text",       False, ""),
        ("length_m",         "Cable length in metres (optional)", "float",  False, ""),
        ("max_load_kg",      "Max load in kg (optional)",     "float",      False, ""),
        ("vesa_pattern",     "VESA pattern (optional)",       "text",       False, ""),
    ],
}


def spec_kind(category):
    """'monitor', 'accessory' or None, depending on the category name."""
    if category in MONITOR_CATEGORIES:
        return "monitor"
    if category in ACCESSORY_CATEGORIES:
        return "accessory"
    return None


def build_specs_summary(kind, data):
    """One-line summary for products.specs, built from the detail fields."""
    d = data or {}
    if kind == "monitor":
        parts = [f'{d["screen_size_in"]:g}"', d["resolution"], d["panel_type"], f'{d["refresh_rate_hz"]}Hz']
        if d.get("response_time_ms"):
            parts.append(f'{d["response_time_ms"]:g}ms')
        if d.get("is_curved"):
            parts.append("Curved")
        if d.get("hdr_support"):
            parts.append(d["hdr_support"])
    elif kind == "accessory":
        parts = [d["accessory_type"].replace("_", " ").title()]
        if d.get("connector_type"):
            parts.append(d["connector_type"])
        if d.get("length_m"):
            parts.append(f'{d["length_m"]:g}m')
        if d.get("max_load_kg"):
            parts.append(f'Up to {d["max_load_kg"]:g}kg')
        if d.get("vesa_pattern"):
            parts.append(f'VESA {d["vesa_pattern"]}')
        if d.get("compatibility"):
            parts.append(d["compatibility"])
    else:
        return ""
    return " • ".join(str(x) for x in parts)[:255]


def hash_password(raw_password):
    """SHA-256 hex digest — matches MySQL's SHA2(str, 256), used by the seed users."""
    return hashlib.sha256(raw_password.encode("utf-8")).hexdigest()


class Database:
    """Thin wrapper around mysql-connector-python for the store app.

    Raises mysql.connector.Error (or a subclass) if the connection or a
    query fails; the caller (the app) is responsible for showing that to
    the user, since this class has no UI of its own.
    """

    def __init__(self, config=None):
        self.config = config or DB_CONFIG
        self.conn = None
        self.connect()

    def connect(self):
        self.conn = mysql.connector.connect(**self.config)
        self.specs_available = self._check_spec_tables()

    def _check_spec_tables(self):
        """True when the monitor/accessory tables exist (migration or full SQL imported).

        If they do not, the app still works exactly as before - it just doesn't
        offer the extra monitor/accessory detail fields.
        """
        try:
            cur = self.conn.cursor()
            try:
                cur.execute("""
                    SELECT COUNT(*) FROM information_schema.tables
                    WHERE table_schema = DATABASE()
                      AND table_name IN ('monitor_specs', 'monitor_accessory_specs')
                """)
                return cur.fetchone()[0] == 2
            finally:
                cur.close()
        except MySQLError:
            return False

    def _ensure_connected(self):
        if self.conn is None or not self.conn.is_connected():
            self.connect()

    def _fetch(self, sql, params=None):
        self._ensure_connected()
        cur = self.conn.cursor(dictionary=True)
        try:
            cur.execute(sql, params or ())
            return cur.fetchall()
        finally:
            cur.close()

    def _execute(self, sql, params=None):
        """INSERT/UPDATE/DELETE. Commits and returns the new row's id (for INSERT)."""
        self._ensure_connected()
        cur = self.conn.cursor()
        try:
            cur.execute(sql, params or ())
            self.conn.commit()
            return cur.lastrowid
        finally:
            cur.close()

    # ---------------- categories ----------------
    def get_categories(self):
        """{"PC & Components": ["CPUs", "GPUs", ...], "Mobile & Accessories": [...]}"""
        rows = self._fetch("""
            SELECT d.name AS department, c.name AS category
            FROM categories c JOIN departments d ON d.id = c.department_id
            ORDER BY d.id, c.id
        """)
        out = {}
        for r in rows:
            out.setdefault(r["department"], []).append(r["category"])
        return out

    # ---------------- products ----------------
    def get_products(self):
        rows = self._fetch("""
            SELECT id, name, department, category, specs, price, rating,
                   icon, image_path AS image, stock
            FROM v_catalog
            ORDER BY category_id, name
        """)
        for r in rows:
            r["price"] = float(r["price"])
            r["rating"] = float(r["rating"])
        return rows

    def name_exists(self, name, exclude_id=None):
        rows = self._fetch("SELECT id FROM products WHERE name = %s", (name,))
        return any(r["id"] != exclude_id for r in rows)

    def add_product(self, category, name, specs, price, rating, icon, image, stock, extra=None):
        """Insert a product (and its monitor/accessory detail row) in one transaction."""
        self._ensure_connected()
        cur = self.conn.cursor()
        try:
            cur.execute("""
                INSERT INTO products (category_id, name, specs, price, rating, icon, image_path, stock)
                VALUES ((SELECT id FROM categories WHERE name = %s), %s, %s, %s, %s, %s, %s, %s)
            """, (category, name, specs, price, rating, icon, image, stock))
            product_id = cur.lastrowid
            self._sync_extra_specs(cur, product_id, category, extra)
            self.conn.commit()
            return product_id
        except MySQLError:
            self.conn.rollback()
            raise
        finally:
            cur.close()

    def update_product(self, product_id, category, name, specs, price, rating, icon, image, stock, extra=None):
        """Update a product (and its detail row) in one transaction."""
        self._ensure_connected()
        cur = self.conn.cursor()
        try:
            cur.execute("""
                UPDATE products
                SET category_id = (SELECT id FROM categories WHERE name = %s),
                    name = %s, specs = %s, price = %s, rating = %s, icon = %s, image_path = %s, stock = %s
                WHERE id = %s
            """, (category, name, specs, price, rating, icon, image, stock, product_id))
            self._sync_extra_specs(cur, product_id, category, extra)
            self.conn.commit()
        except MySQLError:
            self.conn.rollback()
            raise
        finally:
            cur.close()

    def _sync_extra_specs(self, cur, product_id, category, extra):
        """Keep monitor_specs / monitor_accessory_specs consistent with the product's category.

        - A row of the wrong kind (e.g. product moved from Monitors to Cases) is removed.
        - If detail data is supplied for the right kind, the row is replaced.
        Runs on the caller's cursor, so it commits/rolls back together with the product.
        """
        if not self.specs_available:
            return
        kind = spec_kind(category)
        for k, table in SPEC_TABLES.items():
            if k != kind:
                cur.execute(f"DELETE FROM {table} WHERE product_id = %s", (product_id,))
        if kind and extra:
            table = SPEC_TABLES[kind]
            cols = [f[0] for f in SPEC_FIELDS[kind]]
            cur.execute(f"DELETE FROM {table} WHERE product_id = %s", (product_id,))
            cur.execute(
                f"INSERT INTO {table} (product_id, {', '.join(cols)}) "
                f"VALUES (%s{', %s' * len(cols)})",
                [product_id] + [extra.get(c) for c in cols])

    def get_extra_specs(self, product_id, category):
        """Detail fields for a monitor/accessory product as {column: value}, or {} if none."""
        kind = spec_kind(category)
        if not kind or not self.specs_available:
            return {}
        rows = self._fetch(f"SELECT * FROM {SPEC_TABLES[kind]} WHERE product_id = %s", (product_id,))
        if not rows:
            return {}
        row = rows[0]
        out = {}
        for col, *_ in SPEC_FIELDS[kind]:
            v = row.get(col)
            out[col] = float(v) if hasattr(v, "as_tuple") else v   # Decimal -> float
        return out

    def delete_product(self, product_id):
        self._execute("DELETE FROM products WHERE id = %s", (product_id,))

    # ---------------- auth ----------------
    def authenticate(self, username, password):
        """Return (user_id, role) on success, or None on bad username/password."""
        rows = self._fetch(
            "SELECT id, role, password_hash FROM users WHERE username = %s", (username,))
        if not rows or rows[0]["password_hash"] != hash_password(password):
            return None
        return rows[0]["id"], rows[0]["role"]

    def register(self, username, full_name, email, password):
        """Return (user_id, None) on success, or (None, error_message)."""
        if self._fetch("SELECT id FROM users WHERE username = %s", (username,)):
            return None, "That username or email is already registered."
        try:
            uid = self._execute("""
                INSERT INTO users (username, full_name, email, password_hash, role)
                VALUES (%s, %s, %s, %s, 'customer')
            """, (username, full_name, email, hash_password(password)))
            return uid, None
        except MySQLError as err:
            return None, str(err)

    # ---------------- checkout ----------------
    def checkout(self, user_id, cart_items):
        """Place an order atomically and decrement inventory without a stock trigger."""
        if not cart_items:
            return False, "Your cart is empty."

        self._ensure_connected()
        cur = self.conn.cursor(dictionary=True)
        try:
            # Combine repeated product IDs so stock is checked against the total quantity.
            quantities = {}
            for pid, qty in cart_items:
                try:
                    pid, qty = int(pid), int(qty)
                except (TypeError, ValueError):
                    return False, "Invalid item or quantity in your cart."
                if qty < 1:
                    return False, "Item quantities must be at least 1."
                quantities[pid] = quantities.get(pid, 0) + qty

            ids = list(quantities.keys())
            placeholders = ",".join(["%s"] * len(ids))

            # Lock inventory rows until commit/rollback to prevent concurrent overselling.
            cur.execute(f"""
                SELECT p.id, p.name, p.price, p.stock, c.name AS category_name
                FROM products p
                JOIN categories c ON c.id = p.category_id
                WHERE p.id IN ({placeholders})
                FOR UPDATE
            """, ids)
            by_id = {r["id"]: r for r in cur.fetchall()}

            for pid, qty in quantities.items():
                product = by_id.get(pid)
                if product is None:
                    self.conn.rollback()
                    return False, "An item in your cart is no longer available."
                if qty > product["stock"]:
                    self.conn.rollback()
                    return False, f"Not enough stock for {product['name']}."

            cur.execute(
                "INSERT INTO orders (user_id, status) VALUES (%s, 'completed')",
                (user_id,)
            )
            order_id = cur.lastrowid
            total = 0.0

            for pid, qty in quantities.items():
                product = by_id[pid]

                # Conditional update is a second safeguard against overselling.
                cur.execute("""
                    UPDATE products
                    SET stock = stock - %s
                    WHERE id = %s AND stock >= %s
                """, (qty, pid, qty))
                if cur.rowcount != 1:
                    raise RuntimeError(
                        f"Stock changed while checking out {product['name']}. Please try again."
                    )

                cur.execute("""
                    INSERT INTO order_items
                        (order_id, product_id, product_name, category_name, quantity, unit_price)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (
                    order_id, pid, product["name"], product["category_name"],
                    qty, product["price"]
                ))
                total += float(product["price"]) * qty

            cur.execute("UPDATE orders SET total = %s WHERE id = %s", (total, order_id))
            self.conn.commit()
            return True, f"Order placed! Total: ${total:,.2f}\\n(Demo checkout: no real payment.)"
        except (MySQLError, RuntimeError) as err:
            self.conn.rollback()
            return False, f"Checkout failed: {err}"
        finally:
            cur.close()

    # ---------------- analytics ----------------
    def get_sales(self, period, category="All"):
        """period: 'Today' or 'This Week'. Reads from the v_sales view (completed orders only)."""
        where = "sold_at >= CURDATE()" if period == "Today" else "sold_at >= NOW() - INTERVAL 7 DAY"
        params = []
        if category != "All":
            where += " AND category_name = %s"
            params.append(category)
        rows = self._fetch(f"""
            SELECT product_name AS name, category_name AS category, quantity AS qty,
                   unit_price, sold_at AS timestamp
            FROM v_sales WHERE {where}
        """, params)
        for r in rows:
            r["unit_price"] = float(r["unit_price"])
        return rows

    def close(self):
        if self.conn is not None and self.conn.is_connected():
            self.conn.close()
