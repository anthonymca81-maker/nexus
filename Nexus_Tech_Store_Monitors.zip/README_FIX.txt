NEXUS TECH STORE — DATABASE CHECKOUT FIX

What changed:
1. db.py checkout now locks product inventory rows with SELECT ... FOR UPDATE.
2. It checks stock, reduces stock with a guarded UPDATE, inserts order_items using VALUES,
   updates the order total, and commits all changes in one transaction.
3. nexus_tech_store.sql no longer creates the trg_stock_after_sale trigger. Stock changes
   are managed by db.py, avoiding the MySQL/MariaDB table-in-use conflict.

Installation:
1. Back up your existing project and database first.
2. Replace the project's db.py and nexus_tech_store.sql with these fixed versions.
3. IMPORTANT: the supplied SQL script starts with DROP DATABASE IF EXISTS. Importing it
   will erase and recreate nexus_tech_store, including current data. Only re-import it if
   you are okay resetting the database. If you need to keep current data, remove the old
   trg_stock_after_sale trigger in phpMyAdmin (SQL tab) instead:
       DROP TRIGGER IF EXISTS trg_stock_after_sale;
   Then replace db.py with the fixed version. Do not re-import the full SQL file unless
   you have backed up your data.
4. Restart the Python app and test checkout with an item that has enough stock and one
   with insufficient stock.

The application file is included unchanged; only db.py and the SQL schema were modified.
