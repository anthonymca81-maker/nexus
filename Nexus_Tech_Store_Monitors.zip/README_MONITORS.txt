NEXUS TECH STORE - ADDED: MONITORS & ACCESSORIES

NEW DEPARTMENT (appears in the sidebar after "Mobile & Accessories")
  Monitors & Accessories
     - Monitors
     - Monitor Arms
     - Display Cables
     - Webcams & Lights
  Includes 11 sample products (demo data - edit or delete them in the Admin panel).

NEW DATABASE TABLES  (nothing existing was altered or renamed)
  monitor_specs             1-to-1 with products in "Monitors": screen size, resolution, panel type,
                            refresh rate, response time, aspect ratio, curved, HDR, ports
  monitor_accessory_specs   1-to-1 with products in the 3 accessory categories: accessory type,
                            compatibility, connector, cable length, max load, VESA pattern
  Both use product_id as PRIMARY KEY + FOREIGN KEY to products(id) with ON DELETE CASCADE,
  so deleting a product cleans up its spec row. No triggers are used.
  New views: v_monitor_catalog, v_accessory_catalog.
  All existing tables, views, and the v_catalog / v_sales views are unchanged.

FILES
  nexus_tech_store.sql                       Full schema. DROPS and recreates the database (fresh install only).
  migration_add_monitors_accessories.sql     NON-destructive. Keeps all your data. Safe to run more than once.
  db.py                                      Saves product + spec row in one transaction.
  nexus_tech_store.py                        Scrollable sidebar, monitor/accessory fields in the admin form.

INSTALL
  A) You want to KEEP your current data (recommended):
       phpMyAdmin -> select database "nexus_tech_store" -> Import ->
       migration_add_monitors_accessories.sql -> Go.
  B) Fresh start:
       phpMyAdmin -> Import -> nexus_tech_store.sql  (erases the current database!)
  Then replace db.py and nexus_tech_store.py with these versions and restart the app.
  Back up your database first (phpMyAdmin -> Export).

ADMIN USAGE
  Choose a Monitors/accessory category in "Add New Product" and a details section appears.
  Leave "Specs" blank to have the card summary generated from those details.
  If a product is moved to a different category, its old detail row is removed automatically.

If the migration has NOT been run, the app still works exactly as before (the new fields are
simply not shown).
