-- ============================================================
-- NEXUS TECH STORE : database for XAMPP (MariaDB / MySQL)
--
-- HOW TO USE
--   1. Open the XAMPP Control Panel and start Apache + MySQL.
--   2. Go to http://localhost/phpmyadmin  ->  Import  ->  choose this file  ->  Go.
--      (or paste it into the SQL tab)
--   3. Defaults: host localhost, port 3306, user root, empty password.
--
-- PART 1  Create database + tables
-- PART 2  Seed data (categories, 35 products incl. monitors & accessories, demo users, demo sales)
-- PART 3  Triggers + views
-- PART 4  Queries the app needs (login, store, cart/checkout, admin, analytics)
-- ============================================================


-- ============================================================
-- PART 1: DATABASE + TABLES
-- ============================================================
DROP DATABASE IF EXISTS nexus_tech_store;
CREATE DATABASE nexus_tech_store
    CHARACTER SET utf8mb4          -- utf8mb4 is needed for the emoji icons
    COLLATE utf8mb4_unicode_ci;
USE nexus_tech_store;

-- ---------- users (customers + admins) ----------
CREATE TABLE users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(100)  NOT NULL UNIQUE,      -- what people type on the login screen
    full_name     VARCHAR(120)  NOT NULL,
    email         VARCHAR(150)  NULL UNIQUE,
    password_hash VARCHAR(255)  NOT NULL,
    role          ENUM('admin','customer') NOT NULL DEFAULT 'customer',
    created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- departments (top-level groups in the sidebar) ----------
CREATE TABLE departments (
    id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- ---------- categories (CPUs, GPUs, Smartphones, ...) ----------
CREATE TABLE categories (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_id INT UNSIGNED NOT NULL,
    name          VARCHAR(80)  NOT NULL UNIQUE,
    CONSTRAINT fk_cat_dept FOREIGN KEY (department_id)
        REFERENCES departments(id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------- products ----------
CREATE TABLE products (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_id INT UNSIGNED  NOT NULL,
    name        VARCHAR(150)  NOT NULL UNIQUE,
    specs       VARCHAR(255)  NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    rating      DECIMAL(2,1)  NOT NULL DEFAULT 4.5,
    icon        VARCHAR(16)   NOT NULL DEFAULT '📦',   -- emoji fallback
    image_path  VARCHAR(255)  NULL,                    -- e.g. images/sony-wh-1000xm6.png (NULL = auto by name)
    stock       INT           NOT NULL DEFAULT 0,
    is_active   TINYINT(1)    NOT NULL DEFAULT 1,      -- 0 = hidden from the store
    created_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_price  CHECK (price > 0),
    CONSTRAINT chk_rating CHECK (rating BETWEEN 0 AND 5),
    CONSTRAINT chk_stock  CHECK (stock >= 0),          -- blocks overselling
    CONSTRAINT fk_prod_cat FOREIGN KEY (category_id)
        REFERENCES categories(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_prod_category (category_id),
    INDEX idx_prod_active (is_active)
) ENGINE=InnoDB;

-- ---------- orders (one row per checkout) ----------
CREATE TABLE orders (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED  NULL,
    total      DECIMAL(12,2) NOT NULL DEFAULT 0,
    status     ENUM('pending','completed','cancelled') NOT NULL DEFAULT 'completed',
    created_at DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_order_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idx_order_created (created_at),
    INDEX idx_order_status (status)
) ENGINE=InnoDB;

-- ---------- order_items (= your sales_log) ----------
-- product_name / category_name / unit_price are SNAPSHOTS, so sales history
-- and analytics stay correct even if a product is renamed, repriced or deleted.
CREATE TABLE order_items (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id      INT UNSIGNED  NOT NULL,
    product_id    INT UNSIGNED  NULL,
    product_name  VARCHAR(150)  NOT NULL,
    category_name VARCHAR(80)   NOT NULL,
    quantity      INT UNSIGNED  NOT NULL,
    unit_price    DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_qty CHECK (quantity > 0),
    CONSTRAINT fk_item_order FOREIGN KEY (order_id)
        REFERENCES orders(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_item_product FOREIGN KEY (product_id)
        REFERENCES products(id) ON UPDATE CASCADE ON DELETE SET NULL,
    INDEX idx_item_order (order_id),
    INDEX idx_item_name (product_name),
    INDEX idx_item_category (category_name)
) ENGINE=InnoDB;


-- ============================================================
-- MONITORS & ACCESSORIES : new tables
-- Both tables are 1-to-1 extensions of `products` (product_id is the PK AND a
-- foreign key), so they never duplicate or replace anything in existing tables.
-- ON DELETE CASCADE: deleting a product also removes its spec row automatically.
-- No triggers are used (see README_FIX.txt: a stock trigger caused conflicts).
-- ============================================================

-- ---------- monitor_specs: technical details for products in the 'Monitors' category ----------
CREATE TABLE IF NOT EXISTS monitor_specs (
    product_id       INT UNSIGNED  NOT NULL PRIMARY KEY,
    screen_size_in   DECIMAL(4,1)  NOT NULL,                       -- diagonal, inches (e.g. 27.0)
    resolution       VARCHAR(20)   NOT NULL,                       -- e.g. 2560x1440
    panel_type       ENUM('IPS','VA','TN','OLED','QD-OLED','Mini-LED','Other') NOT NULL DEFAULT 'IPS',
    refresh_rate_hz  SMALLINT UNSIGNED NOT NULL DEFAULT 60,
    response_time_ms DECIMAL(5,2)  NULL,                           -- e.g. 1.00 or 0.03
    aspect_ratio     VARCHAR(10)   NOT NULL DEFAULT '16:9',
    is_curved        TINYINT(1)    NOT NULL DEFAULT 0,
    hdr_support      VARCHAR(40)   NULL,
    ports            VARCHAR(200)  NULL,
    updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_mspec_product FOREIGN KEY (product_id)
        REFERENCES products(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_mspec_size    CHECK (screen_size_in > 0),
    CONSTRAINT chk_mspec_refresh CHECK (refresh_rate_hz > 0),
    CONSTRAINT chk_mspec_resp    CHECK (response_time_ms IS NULL OR response_time_ms > 0),
    CONSTRAINT chk_mspec_res     CHECK (resolution REGEXP '^[0-9]+x[0-9]+$'),
    CONSTRAINT chk_mspec_curved  CHECK (is_curved IN (0,1)),
    INDEX idx_mspec_refresh (refresh_rate_hz),
    INDEX idx_mspec_panel (panel_type)
) ENGINE=InnoDB;

-- ---------- monitor_accessory_specs: details for arms, cables, webcams, lights ----------
CREATE TABLE IF NOT EXISTS monitor_accessory_specs (
    product_id     INT UNSIGNED  NOT NULL PRIMARY KEY,
    accessory_type ENUM('arm','stand','cable','adapter','webcam','light_bar','other') NOT NULL DEFAULT 'other',
    compatibility  VARCHAR(200)  NULL,                             -- what it works with
    connector_type VARCHAR(60)   NULL,                             -- e.g. DisplayPort 1.4 (M/M)
    length_m       DECIMAL(5,2)  NULL,                             -- cables
    max_load_kg    DECIMAL(5,2)  NULL,                             -- arms / stands
    vesa_pattern   VARCHAR(40)   NULL,                             -- e.g. 75x75, 100x100
    updated_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_aspec_product FOREIGN KEY (product_id)
        REFERENCES products(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_aspec_len  CHECK (length_m IS NULL OR length_m > 0),
    CONSTRAINT chk_aspec_load CHECK (max_load_kg IS NULL OR max_load_kg > 0),
    INDEX idx_aspec_type (accessory_type)
) ENGINE=InnoDB;


-- ============================================================
-- PART 2: SEED DATA
-- ============================================================

-- ---------- departments & categories ----------
INSERT INTO departments (id, name) VALUES
    (1, 'PC & Components'),
    (2, 'Mobile & Accessories');

INSERT INTO categories (id, department_id, name) VALUES
    (1, 1, 'CPUs'),
    (2, 1, 'GPUs'),
    (3, 1, 'Motherboards'),
    (4, 1, 'RAM'),
    (5, 1, 'Prebuilt PCs'),
    (6, 1, 'Laptops'),
    (7, 2, 'Smartphones'),
    (8, 2, 'Chargers'),
    (9, 2, 'Cases'),
    (10, 2, 'Audio');

-- ---------- products (real devices, USD; see price notes in the app file) ----------
INSERT INTO products (id, category_id, name, specs, price, rating, icon, stock) VALUES
    (1,  2,  'NVIDIA GeForce RTX 5090 Founders Edition', '32GB GDDR7 • 575W • 4K/8K Gaming',                     1999.00, 4.8, '🎮', 5),
    (2,  2,  'NVIDIA GeForce RTX 5080 Founders Edition', '16GB GDDR7 • 360W • 4K Gaming',                        999.00,  4.7, '🎮', 12),
    (3,  1,  'AMD Ryzen 9 9950X3D',                      '16 Cores • 32 Threads • 5.7GHz • 3D V-Cache',         699.00,  4.8, '🧠', 20),
    (4,  1,  'Intel Core Ultra 9 285K',                  '24 Cores • 5.7GHz • LGA1851',                         589.00,  4.4, '🧠', 20),
    (5,  3,  'ASUS ROG Crosshair X870E Hero',            'AM5 • DDR5 • PCIe 5.0 • Wi-Fi 7',                     699.99,  4.7, '🔧', 10),
    (6,  3,  'MSI MAG Z890 Tomahawk WiFi',               'LGA1851 • DDR5 • Wi-Fi 7',                            299.99,  4.6, '🔧', 15),
    (7,  4,  'Corsair Vengeance RGB 32GB DDR5-6000',     '32GB (2×16GB) • 6000MT/s • CL36',                     370.00,  4.6, '💾', 25),
    (8,  4,  'Corsair Vengeance 64GB DDR5-5200',         '64GB (2×32GB) • 5200MT/s • CL40',                     690.00,  4.5, '💾', 15),
    (9,  5,  'Alienware Area-51 (RTX 5090)',             'RTX 5090 • Ryzen 9 9950X3D • 32GB • 2TB',             5299.99, 4.7, '🖥️', 4),
    (10, 5,  'Alienware Area-51 (Base Config)',          'RTX 50-Series • Ryzen X3D • 1500W PSU • Liquid Cooled', 3849.00, 4.6, '🖥️', 6),
    (11, 6,  'Apple MacBook Pro 14-inch (M5)',           '14" Liquid Retina XDR • M5 • 16GB • 512GB',           1599.00, 4.8, '💻', 15),
    (12, 6,  'ASUS ROG Zephyrus G16 (2026)',             '16" OLED 240Hz • Core Ultra 9 386H • RTX 50-Series',  2999.99, 4.6, '💻', 8),
    (13, 7,  'Apple iPhone 17 Pro Max',                  '6.9" OLED • A19 Pro • 256GB • 48MP Camera System',    1199.00, 4.8, '📱', 30),
    (14, 7,  'Samsung Galaxy S26 Ultra',                 '6.9" AMOLED • Snapdragon 8 Elite Gen 5 • 256GB',      1299.99, 4.7, '📱', 30),
    (15, 7,  'Google Pixel 10 Pro',                      '6.3" OLED • Tensor G5 • 256GB • AI Camera',           999.00,  4.6, '📱', 25),
    (16, 8,  'Anker 735 Charger (65W)',                  '65W GaN • 3 Ports • Fast Charging',                   49.99,   4.7, '🔌', 60),
    (17, 8,  'Apple 35W Dual USB-C Power Adapter',       '35W • 2×USB-C • Compact',                             59.00,   4.6, '⚡', 50),
    (18, 8,  'Anker MagGo Power Bank (10K)',             '10,000mAh • Qi2 Magnetic • 15W Wireless',             59.99,   4.5, '🔋', 40),
    (19, 9,  'Apple iPhone 17 Pro Max Silicone Case',    'MagSafe • Silky Silicone • Microfiber Lining',        49.00,   4.5, '🛡️', 100),
    (20, 9,  'Spigen Tough Armor MagFit',                'Dual-Layer • Kickstand • MagSafe Compatible',         29.99,   4.7, '📦', 90),
    (21, 9,  'OtterBox Symmetry Clear (MagSafe)',        'Clear • Drop Protection • MagSafe',                   54.95,   4.6, '📱', 70),
    (22, 10, 'Apple AirPods Pro 3',                      'Active Noise Cancellation • Heart Rate Sensing • USB-C', 249.00, 4.8, '🎧', 55),
    (23, 10, 'Sony WH-1000XM6',                          'Over-Ear • Industry-Leading ANC • 30h Battery',       449.99,  4.8, '🎵', 30),
    (24, 10, 'Bose QuietComfort Ultra Earbuds (2nd Gen)', 'ANC • Spatial Audio • Wireless',                     299.00,  4.6, '🔊', 40);

-- ---------- demo users ----------
-- DEMO ONLY: passwords are hashed with SHA2 so the file works out of the box.
-- In the real app, hash passwords in Python (bcrypt) and store that instead.
--   admin    / admin123
--   customer / customer123
INSERT INTO users (id, username, full_name, email, password_hash, role) VALUES
    (1, 'admin',    'Store Administrator', 'admin@nexus.local',    SHA2('admin123', 256),    'admin'),
    (2, 'customer', 'Demo Customer',       'customer@nexus.local', SHA2('customer123', 256), 'customer');

-- ---------- demo sales so the analytics are not empty ----------
-- (inserted BEFORE the stock trigger exists, so demo sales do not change stock)
INSERT INTO orders (id, user_id, status, created_at) VALUES
    (1,  2, 'completed', NOW() - INTERVAL 10 MINUTE),
    (2,  2, 'completed', NOW() - INTERVAL 25 MINUTE),
    (3,  2, 'completed', NOW() - INTERVAL 40 MINUTE),
    (4,  2, 'completed', NOW() - INTERVAL 55 MINUTE),
    (5,  2, 'completed', NOW() - INTERVAL 1 DAY),
    (6,  2, 'completed', NOW() - INTERVAL 1 DAY),
    (7,  2, 'completed', NOW() - INTERVAL 2 DAY),
    (8,  2, 'completed', NOW() - INTERVAL 2 DAY),
    (9,  2, 'completed', NOW() - INTERVAL 3 DAY),
    (10, 2, 'completed', NOW() - INTERVAL 4 DAY),
    (11, 2, 'completed', NOW() - INTERVAL 5 DAY),
    (12, 2, 'completed', NOW() - INTERVAL 6 DAY);

CREATE TEMPORARY TABLE seed_lines (order_id INT, product_id INT, qty INT);
INSERT INTO seed_lines (order_id, product_id, qty) VALUES
    (1, 13, 1), (1, 20, 2),
    (2, 22, 2), (2, 16, 1),
    (3, 13, 1), (3, 23, 1),
    (4, 20, 3), (4, 18, 1),
    (5, 22, 1), (5, 14, 1), (5, 19, 2),
    (6, 13, 2), (6, 7, 1),
    (7, 2, 1),  (7, 22, 1),
    (8, 20, 2), (8, 16, 2),
    (9, 3, 1),  (9, 8, 1),  (9, 13, 1),
    (10, 23, 1), (10, 15, 1),
    (11, 11, 1), (11, 22, 2),
    (12, 1, 1),  (12, 20, 1);

INSERT INTO order_items (order_id, product_id, product_name, category_name, quantity, unit_price)
SELECT s.order_id, p.id, p.name, c.name, s.qty, p.price
FROM seed_lines s
JOIN products   p ON p.id = s.product_id
JOIN categories c ON c.id = p.category_id;

DROP TEMPORARY TABLE seed_lines;

UPDATE orders o
SET o.total = (SELECT COALESCE(SUM(oi.quantity * oi.unit_price), 0)
               FROM order_items oi WHERE oi.order_id = o.id);


-- ============================================================
-- MONITORS & ACCESSORIES : department, categories, sample products, spec rows
-- Safe to run more than once: every insert checks for an existing row by NAME first.
-- (Sample products/prices are demo data - edit them freely in the Admin panel.)
-- ============================================================

INSERT INTO departments (name)
SELECT 'Monitors & Accessories'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE name = 'Monitors & Accessories');

INSERT INTO categories (department_id, name)
SELECT d.id, v.name
FROM departments d
JOIN (SELECT 'Monitors' AS name
      UNION ALL SELECT 'Monitor Arms'
      UNION ALL SELECT 'Display Cables'
      UNION ALL SELECT 'Webcams & Lights') v
WHERE d.name = 'Monitors & Accessories'
  AND NOT EXISTS (SELECT 1 FROM categories c WHERE c.name = v.name);

INSERT INTO products (category_id, name, specs, price, rating, icon, stock)
SELECT c.id, v.name, v.specs, v.price, v.rating, v.icon, v.stock
FROM (
    SELECT 'Monitors' AS cat, 'LG UltraGear 27GP850-B' AS name, '27" • 2560x1440 • IPS • 165Hz • 1ms • HDR10' AS specs, 299.99 AS price, 4.6 AS rating, '🖥️' AS icon, 14 AS stock
    UNION ALL SELECT 'Monitors', 'Dell UltraSharp U2723QE',       '27" • 3840x2160 • IPS • 60Hz • 5ms • USB-C 90W', 579.99, 4.6, '🖥️', 10
    UNION ALL SELECT 'Monitors', 'Samsung Odyssey G9 G95C 49"',   '49" • 5120x1440 • VA • 240Hz • 1ms • Curved • HDR10+', 999.99, 4.5, '🖥️', 6
    UNION ALL SELECT 'Monitors', 'ASUS ROG Swift OLED PG27AQDM',  '26.5" • 2560x1440 • OLED • 240Hz • 0.03ms • HDR10', 899.99, 4.7, '🖥️', 8
    UNION ALL SELECT 'Monitors', 'AOC 24G2SP',                    '23.8" • 1920x1080 • IPS • 165Hz • 1ms', 139.99, 4.6, '🖥️', 25
    UNION ALL SELECT 'Monitor Arms', 'Ergotron LX Desk Monitor Arm', 'Single Arm • Up to 11.3kg • VESA 75/100 • Height Adjustable', 199.99, 4.8, '🔩', 20
    UNION ALL SELECT 'Monitor Arms', 'VIVO Dual Monitor Desk Mount', 'Dual Arm • 13"-27" • 10kg per Arm • VESA 75/100', 49.99, 4.5, '🔩', 35
    UNION ALL SELECT 'Display Cables', 'Cable Matters DisplayPort 1.4 Cable (6 ft)', 'DisplayPort 1.4 • VESA Certified • 8K/60Hz • 1.8m', 14.99, 4.7, '🔗', 80
    UNION ALL SELECT 'Display Cables', 'Belkin Ultra HD High Speed HDMI 2.1 Cable (6.6 ft)', 'HDMI 2.1 • 48Gbps • 8K/60Hz • 4K/120Hz • 2m', 29.99, 4.6, '🔗', 60
    UNION ALL SELECT 'Webcams & Lights', 'Logitech C920s HD Pro Webcam', '1080p/30fps • Dual Mics • Privacy Shutter • USB', 69.99, 4.6, '📷', 45
    UNION ALL SELECT 'Webcams & Lights', 'BenQ ScreenBar Halo Monitor Light', 'Auto-Dimming • Asymmetric Light • USB-powered • Clamp Mount', 179.00, 4.7, '💡', 18
) v
JOIN categories c ON c.name = v.cat
WHERE NOT EXISTS (SELECT 1 FROM products p WHERE p.name = v.name);

INSERT INTO monitor_specs
    (product_id, screen_size_in, resolution, panel_type, refresh_rate_hz,
     response_time_ms, aspect_ratio, is_curved, hdr_support, ports)
SELECT p.id, v.sz, v.res, v.panel, v.hz, v.resp, v.ratio, v.curved, v.hdr, v.ports
FROM (
    SELECT 'LG UltraGear 27GP850-B' AS pname, 27.0 AS sz, '2560x1440' AS res, 'IPS' AS panel, 165 AS hz, 1.00 AS resp, '16:9' AS ratio, 0 AS curved, 'HDR10' AS hdr, '2x HDMI 2.0, DisplayPort 1.4, USB hub' AS ports
    UNION ALL SELECT 'Dell UltraSharp U2723QE', 27.0, '3840x2160', 'IPS', 60, 5.00, '16:9', 0, 'DisplayHDR 400', 'HDMI, DisplayPort in/out, USB-C 90W PD, RJ45, USB hub'
    UNION ALL SELECT 'Samsung Odyssey G9 G95C 49"', 49.0, '5120x1440', 'VA', 240, 1.00, '32:9', 1, 'HDR10+', 'HDMI 2.1, DisplayPort 1.4, USB hub'
    UNION ALL SELECT 'ASUS ROG Swift OLED PG27AQDM', 26.5, '2560x1440', 'OLED', 240, 0.03, '16:9', 0, 'HDR10', 'DisplayPort 1.4, 2x HDMI 2.0, USB hub'
    UNION ALL SELECT 'AOC 24G2SP', 23.8, '1920x1080', 'IPS', 165, 1.00, '16:9', 0, NULL, '2x HDMI 2.0, DisplayPort'
) v
JOIN products p ON p.name = v.pname
WHERE NOT EXISTS (SELECT 1 FROM monitor_specs m WHERE m.product_id = p.id);

INSERT INTO monitor_accessory_specs
    (product_id, accessory_type, compatibility, connector_type, length_m, max_load_kg, vesa_pattern)
SELECT p.id, v.atype, v.compat, v.conn, v.len_m, v.load_kg, v.vesa
FROM (
    SELECT 'Ergotron LX Desk Monitor Arm' AS pname, 'arm' AS atype, 'Single monitors up to 34 inch' AS compat, 'Desk clamp / grommet' AS conn, NULL AS len_m, 11.30 AS load_kg, '75x75, 100x100' AS vesa
    UNION ALL SELECT 'VIVO Dual Monitor Desk Mount', 'arm', 'Two 13-27 inch monitors', 'Desk clamp / grommet', NULL, 10.00, '75x75, 100x100'
    UNION ALL SELECT 'Cable Matters DisplayPort 1.4 Cable (6 ft)', 'cable', 'DisplayPort 1.4 monitors, GPUs and docks', 'DisplayPort 1.4 (M/M)', 1.83, NULL, NULL
    UNION ALL SELECT 'Belkin Ultra HD High Speed HDMI 2.1 Cable (6.6 ft)', 'cable', 'HDMI 2.1 monitors, consoles and GPUs', 'HDMI 2.1 (M/M)', 2.00, NULL, NULL
    UNION ALL SELECT 'Logitech C920s HD Pro Webcam', 'webcam', 'Windows, macOS, ChromeOS; clips onto monitors', 'USB-A', NULL, NULL, NULL
    UNION ALL SELECT 'BenQ ScreenBar Halo Monitor Light', 'light_bar', 'Clamps onto flat and curved monitors', 'USB-A (5V)', NULL, NULL, NULL
) v
JOIN products p ON p.name = v.pname
WHERE NOT EXISTS (SELECT 1 FROM monitor_accessory_specs a WHERE a.product_id = p.id);


-- ============================================================
-- PART 3: TRIGGER + VIEWS
-- ============================================================

-- Inventory is decremented explicitly in db.py inside the checkout transaction.
-- Do not add an AFTER INSERT trigger here: checkout handles product stock updates
-- directly to avoid the MySQL/MariaDB 'table already in use' conflict.

-- One flat view of every completed sale line (used by all analytics queries).
CREATE VIEW v_sales AS
SELECT oi.id            AS line_id,
       o.id             AS order_id,
       o.created_at     AS sold_at,
       oi.product_id,
       oi.product_name,
       oi.category_name,
       oi.quantity,
       oi.unit_price,
       oi.quantity * oi.unit_price AS line_total
FROM order_items oi
JOIN orders o ON o.id = oi.order_id
WHERE o.status = 'completed';

-- Store catalogue with department + category names (for the product grid).
CREATE VIEW v_catalog AS
SELECT p.id, p.name, p.specs, p.price, p.rating, p.icon, p.image_path, p.stock,
       c.id   AS category_id,
       c.name AS category,
       d.name AS department
FROM products p
JOIN categories  c ON c.id = p.category_id
JOIN departments d ON d.id = c.department_id
WHERE p.is_active = 1;

-- Ready-made top-5 lists for the analytics panels (whole store).
CREATE VIEW v_top_sellers_today AS
SELECT product_name, category_name, SUM(quantity) AS units_sold, SUM(line_total) AS revenue
FROM v_sales
WHERE sold_at >= CURDATE()
GROUP BY product_name, category_name
ORDER BY units_sold DESC
LIMIT 5;

CREATE VIEW v_top_sellers_week AS
SELECT product_name, category_name, SUM(quantity) AS units_sold, SUM(line_total) AS revenue
FROM v_sales
WHERE sold_at >= NOW() - INTERVAL 7 DAY
GROUP BY product_name, category_name
ORDER BY units_sold DESC
LIMIT 5;


-- ============================================================
-- MONITORS & ACCESSORIES : views (CREATE OR REPLACE = safe to re-run)
-- ============================================================
CREATE OR REPLACE VIEW v_monitor_catalog AS
SELECT p.id AS product_id, p.name, p.price, p.rating, p.stock, p.icon, p.image_path,
       c.name AS category,
       m.screen_size_in, m.resolution, m.panel_type, m.refresh_rate_hz,
       m.response_time_ms, m.aspect_ratio, m.is_curved, m.hdr_support, m.ports
FROM products p
JOIN categories    c ON c.id = p.category_id
JOIN monitor_specs m ON m.product_id = p.id
WHERE p.is_active = 1;

CREATE OR REPLACE VIEW v_accessory_catalog AS
SELECT p.id AS product_id, p.name, p.price, p.rating, p.stock, p.icon, p.image_path,
       c.name AS category,
       a.accessory_type, a.compatibility, a.connector_type,
       a.length_m, a.max_load_kg, a.vesa_pattern
FROM products p
JOIN categories              c ON c.id = p.category_id
JOIN monitor_accessory_specs a ON a.product_id = p.id
WHERE p.is_active = 1;


-- ============================================================
-- PART 4: QUERIES THE APP USES
-- (?  = parameter placeholder, use parameterized queries in Python)
-- ============================================================

-- ---------- A. AUTH ----------
-- Register a customer (password_hash comes from Python bcrypt):
--   INSERT INTO users (username, full_name, email, password_hash, role)
--   VALUES (?, ?, ?, ?, 'customer');

-- Login (fetch the row, then verify the hash in Python; role decides admin vs customer screen):
--   SELECT id, username, full_name, role, password_hash FROM users WHERE username = ? LIMIT 1;

-- Demo login check without Python hashing (works with the SHA2 seed users only):
--   SELECT id, role FROM users WHERE username = 'admin' AND password_hash = SHA2('admin123', 256);


-- ---------- B. CUSTOMER STORE ----------
-- All products:
--   SELECT * FROM v_catalog ORDER BY category_id, name;

-- One category (sidebar click):
--   SELECT * FROM v_catalog WHERE category = 'GPUs' ORDER BY name;

-- One department:
--   SELECT * FROM v_catalog WHERE department = 'Mobile & Accessories' ORDER BY category, name;

-- Search box (name, category, specs) combined with a category filter:
--   SELECT * FROM v_catalog
--   WHERE (category = ? OR ? = 'All')
--     AND (name LIKE CONCAT('%', ?, '%') OR category LIKE CONCAT('%', ?, '%') OR specs LIKE CONCAT('%', ?, '%'))
--   ORDER BY name;

-- Sidebar (departments -> categories):
--   SELECT d.name AS department, c.name AS category
--   FROM categories c JOIN departments d ON d.id = c.department_id
--   ORDER BY d.id, c.id;

-- Customer "Best Sellers" panel (units only; swap the date filter for Today / This Week):
--   -- This Week, whole store
--   SELECT product_name, SUM(quantity) AS units_sold
--   FROM v_sales WHERE sold_at >= NOW() - INTERVAL 7 DAY
--   GROUP BY product_name ORDER BY units_sold DESC LIMIT 5;
--   -- Today, one category
--   SELECT product_name, SUM(quantity) AS units_sold
--   FROM v_sales WHERE sold_at >= CURDATE() AND category_name = ?
--   GROUP BY product_name ORDER BY units_sold DESC LIMIT 5;


-- ---------- C. CHECKOUT (run as ONE transaction) ----------
--   START TRANSACTION;
--     INSERT INTO orders (user_id, status) VALUES (?, 'completed');
--     SET @order_id = LAST_INSERT_ID();
--
--     -- one INSERT per cart line; the trigger lowers stock, the CHECK blocks overselling
--     INSERT INTO order_items (order_id, product_id, product_name, category_name, quantity, unit_price)
--     SELECT @order_id, p.id, p.name, c.name, ?, p.price
--     FROM products p JOIN categories c ON c.id = p.category_id
--     WHERE p.id = ?;
--
--     UPDATE orders
--     SET total = (SELECT SUM(quantity * unit_price) FROM order_items WHERE order_id = @order_id)
--     WHERE id = @order_id;
--   COMMIT;      -- on any error (e.g. not enough stock): ROLLBACK;

-- A customer's order history:
--   SELECT o.id, o.created_at, o.total, o.status FROM orders o WHERE o.user_id = ? ORDER BY o.created_at DESC;
--   SELECT product_name, quantity, unit_price, quantity * unit_price AS line_total FROM order_items WHERE order_id = ?;


-- ---------- D. ADMIN: PRODUCT MANAGEMENT ----------
-- Add new product:
--   INSERT INTO products (category_id, name, specs, price, rating, icon, image_path, stock)
--   VALUES ((SELECT id FROM categories WHERE name = ?), ?, ?, ?, ?, ?, ?, ?);

-- Edit product:
--   UPDATE products
--   SET category_id = (SELECT id FROM categories WHERE name = ?),
--       name = ?, specs = ?, price = ?, rating = ?, icon = ?, image_path = ?, stock = ?
--   WHERE id = ?;

-- Restock only:
--   UPDATE products SET stock = stock + ? WHERE id = ?;

-- Delete (hard delete keeps old sales because order_items stores name/price snapshots):
--   DELETE FROM products WHERE id = ?;
-- ...or hide instead of deleting:
--   UPDATE products SET is_active = 0 WHERE id = ?;

-- Admin product list (all, including hidden), with low-stock flag:
--   SELECT p.id, p.name, c.name AS category, p.price, p.stock, p.rating, p.is_active,
--          (p.stock <= 5) AS low_stock
--   FROM products p JOIN categories c ON c.id = p.category_id
--   ORDER BY c.id, p.name;

-- Add a new category to a department:
--   INSERT INTO categories (department_id, name)
--   VALUES ((SELECT id FROM departments WHERE name = ?), ?);


-- ---------- E. ADMIN ANALYTICS (top of the admin dashboard) ----------
-- Period filter: Today  -> sold_at >= CURDATE()
--                Week   -> sold_at >= NOW() - INTERVAL 7 DAY
-- Category filter: add  AND category_name = ?  (omit for "All Products")

-- Top 5 best-selling devices (bar chart):
--   SELECT product_name, SUM(quantity) AS units_sold, SUM(line_total) AS revenue
--   FROM v_sales
--   WHERE sold_at >= NOW() - INTERVAL 7 DAY
--   GROUP BY product_name
--   ORDER BY units_sold DESC
--   LIMIT 5;

-- KPI: units sold + revenue:
--   SELECT COALESCE(SUM(quantity), 0) AS units_sold, COALESCE(SUM(line_total), 0) AS revenue
--   FROM v_sales WHERE sold_at >= CURDATE();

-- KPI: top device:
--   SELECT product_name, SUM(quantity) AS units_sold
--   FROM v_sales WHERE sold_at >= CURDATE()
--   GROUP BY product_name ORDER BY units_sold DESC LIMIT 1;

-- KPI: top category:
--   SELECT category_name, SUM(quantity) AS units_sold
--   FROM v_sales WHERE sold_at >= CURDATE()
--   GROUP BY category_name ORDER BY units_sold DESC LIMIT 1;

-- Units + revenue per category (this week):
--   SELECT category_name, SUM(quantity) AS units_sold, SUM(line_total) AS revenue
--   FROM v_sales WHERE sold_at >= NOW() - INTERVAL 7 DAY
--   GROUP BY category_name ORDER BY units_sold DESC;

-- Daily sales for the last 7 days:
--   SELECT DATE(sold_at) AS day, SUM(quantity) AS units_sold, SUM(line_total) AS revenue
--   FROM v_sales WHERE sold_at >= CURDATE() - INTERVAL 6 DAY
--   GROUP BY DATE(sold_at) ORDER BY day;

-- Devices with no sales this week (slow movers):
--   SELECT p.name, p.stock
--   FROM products p
--   LEFT JOIN v_sales s ON s.product_id = p.id AND s.sold_at >= NOW() - INTERVAL 7 DAY
--   WHERE s.line_id IS NULL
--   ORDER BY p.name;


-- ---------- F. MONITORS & ACCESSORIES ----------
-- All monitors with their specs (filter by size / refresh rate / panel):
--   SELECT * FROM v_monitor_catalog WHERE refresh_rate_hz >= ? ORDER BY price;
-- All accessories of one type:
--   SELECT * FROM v_accessory_catalog WHERE accessory_type = ? ORDER BY price;
-- Save monitor specs for a product (admin form; run inside the same transaction as the product save):
--   DELETE FROM monitor_specs WHERE product_id = ?;
--   INSERT INTO monitor_specs (product_id, screen_size_in, resolution, panel_type, refresh_rate_hz,
--                              response_time_ms, aspect_ratio, is_curved, hdr_support, ports)
--   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
-- Deleting a product removes its monitor_specs / monitor_accessory_specs row automatically (ON DELETE CASCADE).


-- ============================================================
-- QUICK CHECKS (these run when you import; results appear in phpMyAdmin)
-- ============================================================
SELECT 'products' AS tbl, COUNT(*) AS `rows` FROM products
UNION ALL SELECT 'categories', COUNT(*) FROM categories
UNION ALL SELECT 'users',      COUNT(*) FROM users
UNION ALL SELECT 'orders',     COUNT(*) FROM orders
UNION ALL SELECT 'order_items',COUNT(*) FROM order_items
UNION ALL SELECT 'monitor_specs', COUNT(*) FROM monitor_specs
UNION ALL SELECT 'monitor_accessory_specs', COUNT(*) FROM monitor_accessory_specs;

SELECT * FROM v_top_sellers_week;
