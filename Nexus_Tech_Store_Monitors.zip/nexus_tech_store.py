"""
NEXUS TECH STORE
Frontend-only desktop e-commerce app (customer store + admin dashboard).

Install:   pip install customtkinter mysql-connector-python
Run:       python nexus_tech_store.py

Database (required): a local MySQL/MariaDB server via XAMPP.
  1. Start Apache + MySQL in the XAMPP Control Panel.
  2. Import nexus_tech_store.sql once, in phpMyAdmin (http://localhost/phpmyadmin).
     (Already have data? Import migration_add_monitors_accessories.sql instead - it keeps
     everything and only adds the Monitors & Accessories department and its tables.)
  3. Connection settings are in db.py (DB_CONFIG) - XAMPP defaults out of the box.

Demo admin login:  username: admin   password: admin123
Demo customer:     username: customer  password: customer123
Any other username you register with becomes a new customer account.

No mock/in-memory data: products, categories, users, cart checkout, and sales
analytics all read from and write to the MySQL database via db.py.

PRODUCT IMAGES
  Put image files in an "images" folder next to this script. Name each file after
  the product (lowercase, dashes), e.g. images/sony-wh-1000xm6.png. See images/README.txt
  for the exact filename of every product. Missing images fall back to the emoji icon.
  Admins can also attach an image when adding/editing a product.
"""

import re
import shutil
from collections import defaultdict
from pathlib import Path
from tkinter import filedialog, messagebox

import customtkinter as ctk
from mysql.connector import Error as MySQLError
from PIL import Image  # installed automatically with customtkinter

from db import Database, SPEC_FIELDS, build_specs_summary, spec_kind


# ============================================================
# CONSTANTS
# ============================================================
DARK_BG, DARK_PANEL, DARK_CARD, DARK_BORDER = "#080b10", "#10151d", "#151c26", "#263242"
LIGHT_BG, LIGHT_PANEL, LIGHT_CARD, LIGHT_BORDER = "#f3f6fa", "#ffffff", "#ffffff", "#d8e0ea"
NEON, NEON_BLUE = "#67ffb1", "#4da3ff"

GREEN = ("#1e7d50", "#18b96c")
GREEN_HOVER = ("#176741", "#12d879")
GREEN_TEXT = ("white", "#06140d")
BAR_BLUE = ("#3b82f6", "#4da3ff")
MUTED = ("gray45", "#8fa0b4")

ADMIN_USER, ADMIN_PASS = "admin", "admin123"

IMAGE_DIR = Path(__file__).resolve().parent / "images"
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp")

# (categories and products now come from the database - see db.py)


# ============================================================
# SMALL UI HELPERS
# ============================================================
def green_btn(parent, text, command, **kw):
    kw.setdefault("height", 36)
    kw.setdefault("corner_radius", 9)
    return ctk.CTkButton(
        parent, text=text, command=command, fg_color=GREEN, hover_color=GREEN_HOVER,
        text_color=GREEN_TEXT, font=ctk.CTkFont(size=12, weight="bold"), **kw,
    )


def link_btn(parent, text, command, **kw):
    return ctk.CTkButton(
        parent, text=text, command=command, fg_color="transparent",
        hover_color=("#e8f0f8", "#1b2633"), text_color=(NEON_BLUE, NEON), **kw,
    )


def danger_btn(parent, text, command, **kw):
    return ctk.CTkButton(
        parent, text=text, command=command, fg_color="transparent",
        hover_color=("#ffe8e8", "#351d24"), text_color=("#c13f3f", "#ff7777"), **kw,
    )


def shorten(text, n):
    return text if len(text) <= n else text[: n - 1] + "…"


def slugify(name):
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


def find_image(product):
    """Return the image Path for a product, or None (emoji fallback is used)."""
    explicit = product.get("image")
    if explicit and Path(explicit).is_file():
        return Path(explicit)
    for ext in IMAGE_EXTS:
        f = IMAGE_DIR / f"{slugify(product['name'])}{ext}"
        if f.is_file():
            return f
    return None


# ============================================================
# APPLICATION CONTROLLER
# ============================================================
class NexusTechStoreApp(ctk.CTk):
    """Owns all shared state and switches between screens."""

    def __init__(self):
        super().__init__()
        self.title("NEXUS TECH STORE")
        self.geometry("1200x750")
        self.resizable(False, False)
        self.center_window(1200, 750)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")

        # ---- database connection ----
        try:
            self.db = Database()
            self.categories = self.db.get_categories()
            self.products = self.db.get_products()
        except MySQLError as err:
            messagebox.showerror(
                "Database Connection Error",
                "Could not connect to the MySQL database.\n\n"
                "Make sure XAMPP's MySQL service is running and that "
                "nexus_tech_store.sql has been imported in phpMyAdmin.\n\n"
                f"Details: {err}")
            self.destroy()
            raise SystemExit(1)

        # ---- shared state ----
        self.cart = {}  # product id -> quantity
        self.current_user = None
        self.current_user_id = None
        self.current_role = None  # "admin" or "customer"
        self.dark_mode = True
        self.cart_window = None
        self.form_window = None
        self.image_cache = {}

        self.container = ctk.CTkFrame(self, corner_radius=0)
        self.container.pack(fill="both", expand=True)
        self.frames = {}
        for cls in (LoginFrame, RegisterFrame, LandingFrame, StoreFrame, AdminFrame):
            frame = cls(self.container, self)
            self.frames[cls.__name__] = frame
            frame.place(x=0, y=0, relwidth=1, relheight=1)

        self.show_frame("LoginFrame")

    # ---------------- window / navigation ----------------
    def center_window(self, w, h):
        self.update_idletasks()
        x = max(0, (self.winfo_screenwidth() - w) // 2)
        y = max(0, (self.winfo_screenheight() - h) // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def show_frame(self, name):
        if name == "AdminFrame" and self.current_role != "admin":
            return  # customers can never reach admin screens
        frame = self.frames[name]
        frame.tkraise()
        if hasattr(frame, "refresh"):
            frame.refresh()

    def refresh_all(self):
        self.frames["StoreFrame"].refresh()
        self.frames["AdminFrame"].refresh()
        if self.cart_window is not None and self.cart_window.winfo_exists():
            self.cart_window.render()

    # ---------------- auth ----------------
    def login(self):
        f = self.frames["LoginFrame"]
        user, pw = f.email_entry.get().strip(), f.password_entry.get()
        if not user or not pw:
            messagebox.showwarning("Missing Information", "Please enter your username/email and password.")
            return
        try:
            result = self.db.authenticate(user, pw)
        except MySQLError as err:
            messagebox.showerror("Database Error", f"Could not reach the database:\n{err}")
            return
        if result is None:
            messagebox.showerror("Login Failed", "Invalid username or password.")
            return
        uid, role = result
        self.current_user, self.current_user_id, self.current_role = user, uid, role
        self.show_frame("AdminFrame" if role == "admin" else "LandingFrame")

    def register(self):
        f = self.frames["RegisterFrame"]
        name, email = f.name_entry.get().strip(), f.email_entry.get().strip()
        pw, confirm = f.password_entry.get(), f.confirm_entry.get()
        if not all([name, email, pw, confirm]):
            messagebox.showwarning("Missing Information", "Please complete every registration field.")
            return
        if pw != confirm:
            messagebox.showerror("Password Mismatch", "Password and confirmation do not match.")
            return
        if email.lower() == ADMIN_USER:
            messagebox.showerror("Not Allowed", "That username is reserved.")
            return
        try:
            uid, err = self.db.register(email, name, email, pw)
        except MySQLError as err:
            messagebox.showerror("Database Error", f"Could not reach the database:\n{err}")
            return
        if err:
            messagebox.showerror("Registration Failed", err)
            return
        self.current_user, self.current_user_id, self.current_role = email, uid, "customer"
        messagebox.showinfo("Account Created", "Your NEXUS account has been created.")
        self.show_frame("LandingFrame")

    def logout(self):
        self.current_user, self.current_user_id, self.current_role = None, None, None
        self.cart.clear()
        for w in (self.cart_window, self.form_window):
            if w is not None and w.winfo_exists():
                w.destroy()
        self.cart_window = self.form_window = None
        login = self.frames["LoginFrame"]
        login.email_entry.delete(0, "end")
        login.password_entry.delete(0, "end")
        self.show_frame("LoginFrame")

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        ctk.set_appearance_mode("dark" if self.dark_mode else "light")
        self.refresh_all()

    # ---------------- products ----------------
    def reload_products(self):
        self.products = self.db.get_products()

    def all_categories(self):
        return [c for cats in self.categories.values() for c in cats]

    def dept_of(self, category):
        for d, cats in self.categories.items():
            if category in cats:
                return d
        return ""

    def product_by_id(self, pid):
        return next((p for p in self.products if p["id"] == pid), None)

    def icon_for(self, name):
        return next((p["icon"] for p in self.products if p["name"] == name), "📦")

    def get_image(self, product, box=(210, 85)):
        """CTkImage scaled to fit inside `box`, or None if the product has no image file."""
        path = find_image(product)
        if path is None:
            return None
        key = (str(path), path.stat().st_mtime, box)
        if key not in self.image_cache:
            try:
                img = Image.open(path).convert("RGBA")
                w, h = img.size
                scale = min(box[0] / w, box[1] / h)
                self.image_cache[key] = ctk.CTkImage(
                    light_image=img, dark_image=img, size=(max(1, int(w * scale)), max(1, int(h * scale))))
            except Exception:
                self.image_cache[key] = None
        return self.image_cache[key]

    def delete_product(self, product):
        try:
            self.db.delete_product(product["id"])
        except MySQLError as err:
            messagebox.showerror("Database Error", f"Could not delete the product:\n{err}")
            return
        self.cart.pop(product["id"], None)
        self.reload_products()
        self.refresh_all()

    # ---------------- cart ----------------
    def cart_count(self):
        return sum(self.cart.values())

    def cart_total(self):
        total = 0.0
        for pid, qty in self.cart.items():
            p = self.product_by_id(pid)
            if p:
                total += p["price"] * qty
        return total

    def change_qty(self, pid, delta):
        p = self.product_by_id(pid)
        if p is None:
            self.cart.pop(pid, None)
        else:
            new = self.cart.get(pid, 0) + delta
            if new > p["stock"]:
                messagebox.showinfo("Stock Limit", f"Only {p['stock']} of {p['name']} in stock.")
                return False
            if new <= 0:
                self.cart.pop(pid, None)
            else:
                self.cart[pid] = new
        self.frames["StoreFrame"].update_cart_button()
        if self.cart_window is not None and self.cart_window.winfo_exists():
            self.cart_window.render()
        return True

    def open_cart(self):
        w = self.cart_window
        if w is not None and w.winfo_exists():
            w.render()
            w.lift()
            w.focus()
            return
        self.cart_window = CartWindow(self)

    def checkout(self):
        if not self.cart:
            return False, "Your cart is empty."
        try:
            ok, msg = self.db.checkout(self.current_user_id, list(self.cart.items()))
        except MySQLError as err:
            return False, f"Could not reach the database:\n{err}"
        if ok:
            self.cart.clear()
            self.reload_products()
            self.refresh_all()
        return ok, msg

    # ---------------- analytics helpers ----------------
    def get_sales(self, period, category="All"):
        try:
            return self.db.get_sales(period, category)
        except MySQLError as err:
            messagebox.showerror("Database Error", f"Could not load sales data:\n{err}")
            return []

    @staticmethod
    def rank(sales, key):
        totals = defaultdict(int)
        for s in sales:
            totals[s[key]] += s["qty"]
        return sorted(totals.items(), key=lambda kv: kv[1], reverse=True)


# ============================================================
# LOGIN
# ============================================================
class LoginFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        self.controller = controller
        self.password_visible = False

        left = ctk.CTkFrame(self, width=570, corner_radius=0, fg_color=("#e8edf4", "#0c121a"))
        left.pack(side="left", fill="both")
        left.pack_propagate(False)
        right = ctk.CTkFrame(self, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        right.pack(side="left", fill="both", expand=True)

        ctk.CTkLabel(left, text="NEXUS", font=ctk.CTkFont(size=52, weight="bold"),
                     text_color=("#182332", NEON)).place(relx=0.12, rely=0.24)
        ctk.CTkLabel(left, text="TECH STORE", font=ctk.CTkFont(size=24, weight="bold"),
                     text_color=("#46566a", "#9db0c7")).place(relx=0.125, rely=0.34)
        ctk.CTkLabel(left, text="PERFORMANCE\nWITHOUT LIMITS", justify="left",
                     font=ctk.CTkFont(size=28, weight="bold"),
                     text_color=("#1e2d3e", "#e7f0fa")).place(relx=0.125, rely=0.49)
        ctk.CTkLabel(left, text="Rigs  •  Laptops  •  Components  •  Monitors\nPhones  •  Chargers  •  Cases  •  Audio",
                     justify="left", font=ctk.CTkFont(size=15),
                     text_color=("#5a6879", "#879ab0")).place(relx=0.125, rely=0.68)
        ctk.CTkLabel(left, text="◈ CPU    ◈ GPU    ◈ MONITORS    ◈ PHONES    ◈ AUDIO",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=(NEON_BLUE, NEON)).place(relx=0.125, rely=0.84)

        card = ctk.CTkFrame(right, width=410, height=520, corner_radius=24,
                            fg_color=(LIGHT_PANEL, DARK_PANEL), border_width=1,
                            border_color=(LIGHT_BORDER, DARK_BORDER))
        card.place(relx=0.5, rely=0.5, anchor="center")
        card.pack_propagate(False)

        ctk.CTkLabel(card, text="SIGN IN", font=ctk.CTkFont(size=29, weight="bold")).pack(pady=(45, 5))
        ctk.CTkLabel(card, text="Access your NEXUS workspace", text_color=MUTED).pack(pady=(0, 28))

        self.email_entry = ctk.CTkEntry(card, width=320, height=46, corner_radius=10,
                                        placeholder_text="Email or username")
        self.email_entry.pack(pady=8)

        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(pady=8)
        self.password_entry = ctk.CTkEntry(row, width=270, height=46, corner_radius=10,
                                           placeholder_text="Password", show="•")
        self.password_entry.pack(side="left")
        self.password_entry.bind("<Return>", lambda e: controller.login())
        ctk.CTkButton(row, text="◉", width=44, height=46, corner_radius=10,
                      command=self.toggle_password).pack(side="left", padx=(6, 0))

        green_btn(card, "LOGIN", controller.login, width=320, height=48, corner_radius=10).pack(pady=(20, 12))
        link_btn(card, "New user? Create an account",
                 lambda: controller.show_frame("RegisterFrame")).pack()
        ctk.CTkLabel(card, text=f"Admin demo: {ADMIN_USER} / {ADMIN_PASS}",
                     font=ctk.CTkFont(size=11), text_color=MUTED).pack(pady=(18, 0))

    def toggle_password(self):
        self.password_visible = not self.password_visible
        self.password_entry.configure(show="" if self.password_visible else "•")


# ============================================================
# REGISTER
# ============================================================
class RegisterFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        self.controller = controller

        ctk.CTkLabel(self, text="NEXUS TECH STORE", font=ctk.CTkFont(size=34, weight="bold"),
                     text_color=("#1d2c3e", NEON)).pack(pady=(55, 5))
        ctk.CTkLabel(self, text="Create your NEXUS account",
                     font=ctk.CTkFont(size=23, weight="bold")).pack(pady=(0, 22))

        card = ctk.CTkFrame(self, width=440, height=470, corner_radius=24,
                            fg_color=(LIGHT_PANEL, DARK_PANEL), border_width=1,
                            border_color=(LIGHT_BORDER, DARK_BORDER))
        card.pack()
        card.pack_propagate(False)

        self.name_entry = self.make_entry(card, "Full name")
        self.email_entry = self.make_entry(card, "Email address")
        self.password_entry = self.make_entry(card, "Password", show="•")
        self.confirm_entry = self.make_entry(card, "Confirm password", show="•")

        green_btn(card, "CREATE ACCOUNT", controller.register, width=320, height=48,
                  corner_radius=10).pack(pady=(22, 12))
        link_btn(card, "← Back to Login", lambda: controller.show_frame("LoginFrame")).pack()

    @staticmethod
    def make_entry(parent, placeholder, show=None):
        e = ctk.CTkEntry(parent, width=320, height=44, corner_radius=10,
                         placeholder_text=placeholder, show=show)
        e.pack(pady=(26, 7) if placeholder == "Full name" else 7)
        return e


# ============================================================
# LANDING
# ============================================================
class LandingFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        self.controller = controller

        header = ctk.CTkFrame(self, height=78, corner_radius=0, fg_color=(LIGHT_PANEL, DARK_PANEL))
        header.pack(fill="x")
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="NEXUS TECH STORE", font=ctk.CTkFont(size=22, weight="bold"),
                     text_color=("#1d2c3e", NEON)).pack(side="left", padx=40)
        ctk.CTkButton(header, text="Enter Store →", width=130, height=38, corner_radius=19,
                      command=lambda: controller.show_frame("StoreFrame")).pack(side="right", padx=(0, 35))
        danger_btn(header, "Logout", controller.logout, width=70).pack(side="right", padx=5)

        content = ctk.CTkFrame(self, fg_color="transparent")
        content.place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(content, text="NEXUS PERFORMANCE LAB", font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=(NEON_BLUE, NEON)).pack(pady=(0, 14))
        ctk.CTkLabel(content, text="Everything Tech, One Store:\nRigs, Monitors, Phones & Accessories",
                     font=ctk.CTkFont(size=38, weight="bold"), justify="center").pack()
        ctk.CTkLabel(content, text="Gaming hardware, monitors and desk gear, creator machines, mobile devices, power and audio.",
                     font=ctk.CTkFont(size=17), text_color=("gray40", "gray65")).pack(pady=24)
        green_btn(content, "SHOP NOW  →", lambda: controller.show_frame("StoreFrame"),
                  width=240, height=55, corner_radius=27).pack()

        bar = ctk.CTkFrame(self, width=850, height=100, corner_radius=20, fg_color=("#e5ebf2", "#101923"),
                           border_width=1, border_color=(LIGHT_BORDER, DARK_BORDER))
        bar.place(relx=0.5, rely=0.84, anchor="center")
        bar.pack_propagate(False)
        for icon, text in [("⚡", "Extreme Performance"), ("🎮", "Gaming Ready"), ("🖥️", "Monitors & Gear"),
                           ("📱", "Latest Mobile"), ("🎧", "Premium Audio")]:
            block = ctk.CTkFrame(bar, fg_color="transparent")
            block.pack(side="left", expand=True, fill="both")
            ctk.CTkLabel(block, text=icon, font=ctk.CTkFont(size=24)).pack(pady=(17, 2))
            ctk.CTkLabel(block, text=text, font=ctk.CTkFont(size=12, weight="bold"),
                         text_color=("gray35", "gray70")).pack()


# ============================================================
# SHARED CATEGORY SIDEBAR
# ============================================================
class CategorySidebar(ctk.CTkScrollableFrame):
    """Scrollable so the list still fits the fixed-size window as categories are added."""

    def __init__(self, parent, controller, on_select):
        super().__init__(parent, width=192, corner_radius=0, fg_color=("#edf1f6", "#0d141c"))
        self.on_select = on_select
        self.buttons = {}
        self._add("All Products", "All", (16, 2))
        for dept, cats in controller.categories.items():
            ctk.CTkLabel(self, text=dept.upper(), font=ctk.CTkFont(size=11, weight="bold"),
                         text_color=("gray35", "#93a5ba")).pack(anchor="w", padx=20, pady=(16, 4))
            for cat in cats:
                self._add(cat, cat, 1)

    def _add(self, text, key, pady):
        btn = ctk.CTkButton(self, text=text, height=32, anchor="w", fg_color="transparent",
                            hover_color=("#dfe8f1", "#1a2837"), text_color=("#243447", "#d3deeb"),
                            command=lambda k=key: self.on_select(k))
        btn.pack(fill="x", padx=10, pady=pady)
        self.buttons[key] = btn

    def highlight(self, selected):
        for key, btn in self.buttons.items():
            btn.configure(fg_color=("#cdeedd", "#163a29") if key == selected else "transparent")


# ============================================================
# CUSTOMER STORE
# ============================================================
class StoreFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        self.controller = controller
        self.selected_category = "All"
        self.build_ui()

    def build_ui(self):
        c = self.controller
        header = ctk.CTkFrame(self, height=72, corner_radius=0, fg_color=(LIGHT_PANEL, DARK_PANEL),
                              border_width=1, border_color=(LIGHT_BORDER, DARK_BORDER))
        header.pack(fill="x")
        header.pack_propagate(False)

        ctk.CTkLabel(header, text="NEXUS", font=ctk.CTkFont(size=21, weight="bold"),
                     text_color=("#182838", NEON)).pack(side="left", padx=(20, 4))
        ctk.CTkLabel(header, text="TECH STORE", font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=("gray40", "#a6b6c9")).pack(side="left", padx=(0, 20))
        self.search_entry = ctk.CTkEntry(header, width=380, height=40, corner_radius=10,
                                         placeholder_text="Search GPUs, monitors, phones, audio...")
        self.search_entry.pack(side="left", padx=7)
        self.search_entry.bind("<KeyRelease>", lambda e: self.refresh_products())

        self.theme_switch = ctk.CTkSwitch(header, text="", width=45, command=c.toggle_theme)
        self.theme_switch.pack(side="right", padx=(5, 15))
        danger_btn(header, "Logout", c.logout, width=65, height=34).pack(side="right", padx=4)
        self.cart_button = green_btn(header, "🛒 0", c.open_cart, width=80, height=34, corner_radius=17)
        self.cart_button.pack(side="right", padx=5)
        self.admin_btn = ctk.CTkButton(header, text="← Admin Panel", width=110, height=34,
                                       command=lambda: c.show_frame("AdminFrame"))

        body = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        body.pack(fill="both", expand=True)
        self.sidebar = CategorySidebar(body, c, self.set_category)
        self.sidebar.pack(side="left", fill="y")
        main = ctk.CTkFrame(body, fg_color="transparent", corner_radius=0)
        main.pack(side="left", fill="both", expand=True)

        # ---- customer-facing "Best Sellers" analytics strip ----
        self.trend_period = "Today"
        self.trend_panel = ctk.CTkFrame(main, height=150, corner_radius=16, fg_color=(LIGHT_PANEL, DARK_PANEL),
                                        border_width=1, border_color=(LIGHT_BORDER, DARK_BORDER))
        self.trend_panel.pack(fill="x", padx=14, pady=(12, 0))
        self.trend_panel.pack_propagate(False)
        top = ctk.CTkFrame(self.trend_panel, fg_color="transparent")
        top.pack(fill="x", padx=16, pady=(10, 0))
        self.trend_title = ctk.CTkLabel(top, text="", font=ctk.CTkFont(size=16, weight="bold"))
        self.trend_title.pack(side="left")
        self.trend_toggle = ctk.CTkSegmentedButton(top, values=["Today", "This Week"],
                                                   command=self.set_trend_period)
        self.trend_toggle.set(self.trend_period)
        self.trend_toggle.pack(side="right")
        self.trend_row = ctk.CTkFrame(self.trend_panel, fg_color="transparent")
        self.trend_row.pack(fill="both", expand=True, padx=10, pady=(6, 8))

        self.product_area = ctk.CTkScrollableFrame(main, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        self.product_area.pack(fill="both", expand=True)
        self.refresh_trending()
        self.refresh_products()

    def set_category(self, category):
        self.selected_category = category
        self.sidebar.highlight(category)
        self.refresh_trending()
        self.refresh_products()

    def refresh(self):
        c = self.controller
        if c.dark_mode:
            self.theme_switch.select()
        else:
            self.theme_switch.deselect()
        self.admin_btn.pack_forget()
        if c.current_role == "admin":
            self.admin_btn.pack(side="right", padx=8)
        self.sidebar.highlight(self.selected_category)
        self.update_cart_button()
        self.refresh_trending()
        self.refresh_products()

    def set_trend_period(self, period):
        self.trend_period = period
        self.refresh_trending()

    def refresh_trending(self):
        """Top 5 best sellers for the selected category (units only, no revenue for customers)."""
        c = self.controller
        cat = self.selected_category
        scope = "All Categories" if cat == "All" else cat
        self.trend_title.configure(text=f"🔥 Best Sellers · {scope}")
        for w in self.trend_row.winfo_children():
            w.destroy()

        ranked = c.rank(c.get_sales(self.trend_period, cat), "name")[:5]
        if not ranked:
            when = "today" if self.trend_period == "Today" else "this week"
            ctk.CTkLabel(self.trend_row, text=f"No sales yet {when} in {scope}.",
                         text_color=MUTED).pack(expand=True)
            return
        for i, (name, sold) in enumerate(ranked):
            card = ctk.CTkFrame(self.trend_row, corner_radius=12, fg_color=(LIGHT_BG, DARK_BG))
            card.pack(side="left", fill="both", expand=True, padx=4)
            ctk.CTkLabel(card, text=f"#{i + 1}", font=ctk.CTkFont(size=11, weight="bold"),
                         text_color=GREEN).pack(anchor="w", padx=10, pady=(6, 0))
            ctk.CTkLabel(card, text=f"{c.icon_for(name)} {shorten(name, 17)}",
                         font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=10)
            ctk.CTkLabel(card, text=f"{sold} sold", text_color=MUTED).pack(anchor="w", padx=10, pady=(0, 6))

    def refresh_products(self):
        for w in self.product_area.winfo_children():
            w.destroy()
        q = self.search_entry.get().strip().lower()
        items = [
            p for p in self.controller.products
            if (self.selected_category == "All" or p["category"] == self.selected_category)
            and (not q or q in p["name"].lower() or q in p["category"].lower() or q in p["specs"].lower())
        ]

        title_row = ctk.CTkFrame(self.product_area, fg_color="transparent")
        title_row.grid(row=0, column=0, columnspan=3, sticky="ew", padx=10, pady=(10, 15))
        title = "Featured Tech" if self.selected_category == "All" else self.selected_category
        ctk.CTkLabel(title_row, text=title, font=ctk.CTkFont(size=27, weight="bold")).pack(side="left")
        ctk.CTkLabel(title_row, text=f"{len(items)} products", text_color=MUTED).pack(
            side="left", padx=12, pady=(7, 0))

        for i, p in enumerate(items):
            self.create_card(p, i // 3 + 1, i % 3)
        for col in range(3):
            self.product_area.grid_columnconfigure(col, weight=1)

    def create_card(self, p, row, col):
        card = ctk.CTkFrame(self.product_area, width=260, height=290, corner_radius=18,
                            fg_color=(LIGHT_CARD, DARK_CARD), border_width=1,
                            border_color=(LIGHT_BORDER, DARK_BORDER))
        card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
        card.grid_propagate(False)

        photo = self.controller.get_image(p)
        box = ctk.CTkFrame(card, width=230, height=95, corner_radius=14,
                           fg_color="#ffffff" if photo else ("#eaf0f6", "#1a2633"))
        box.pack(padx=14, pady=(14, 8))
        box.pack_propagate(False)
        if photo:
            ctk.CTkLabel(box, text="", image=photo).pack(expand=True)
        else:
            ctk.CTkLabel(box, text=p["icon"], font=ctk.CTkFont(size=44)).pack(expand=True)

        ctk.CTkLabel(card, text=p["name"], font=ctk.CTkFont(size=15, weight="bold"),
                     anchor="w").pack(fill="x", padx=17)
        ctk.CTkLabel(card, text=p["specs"], font=ctk.CTkFont(size=11), text_color=MUTED,
                     anchor="w", justify="left", wraplength=225).pack(fill="x", padx=17, pady=(3, 0))

        info = ctk.CTkFrame(card, fg_color="transparent")
        info.pack(fill="x", padx=17, pady=(6, 4))
        ctk.CTkLabel(info, text=f"${p['price']:,.2f}", font=ctk.CTkFont(size=17, weight="bold")).pack(side="left")
        ctk.CTkLabel(info, text=f"★ {p['rating']}", text_color=("#c48400", "#ffbf3d")).pack(side="right")

        if p["stock"] <= 0:
            ctk.CTkButton(card, text="OUT OF STOCK", height=36, state="disabled",
                          corner_radius=9).pack(fill="x", padx=17, pady=(2, 12))
        else:
            green_btn(card, "ADD TO CART", lambda pr=p: self.add_to_cart(pr)).pack(
                fill="x", padx=17, pady=(2, 12))

    def add_to_cart(self, product):
        self.controller.change_qty(product["id"], 1)

    def update_cart_button(self):
        self.cart_button.configure(text=f"🛒 {self.controller.cart_count()}")


# ============================================================
# CART WINDOW
# ============================================================
class CartWindow(ctk.CTkToplevel):
    def __init__(self, controller):
        super().__init__(controller)
        self.controller = controller
        self.title("Shopping Cart")
        self.geometry("500x560")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.close)

        ctk.CTkLabel(self, text="🛒 Your Cart", font=ctk.CTkFont(size=22, weight="bold")).pack(
            anchor="w", padx=20, pady=(18, 4))
        self.list_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.list_frame.pack(fill="both", expand=True, padx=14, pady=6)

        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(fill="x", padx=20, pady=(4, 16))
        self.total_label = ctk.CTkLabel(footer, text="", font=ctk.CTkFont(size=18, weight="bold"))
        self.total_label.pack(side="left")
        green_btn(footer, "CHECKOUT", self.do_checkout, width=140, height=40).pack(side="right")

        self.render()
        self.after(150, self._front)

    def _front(self):
        if self.winfo_exists():
            self.lift()
            self.focus()

    def render(self):
        c = self.controller
        for w in self.list_frame.winfo_children():
            w.destroy()
        if not c.cart:
            ctk.CTkLabel(self.list_frame, text="Your cart is empty.", text_color=MUTED).pack(pady=40)
        for pid, qty in list(c.cart.items()):
            p = c.product_by_id(pid)
            if p is None:
                continue
            row = ctk.CTkFrame(self.list_frame, corner_radius=10, fg_color=(LIGHT_CARD, DARK_CARD))
            row.pack(fill="x", pady=4)
            ctk.CTkLabel(row, text=p["icon"], font=ctk.CTkFont(size=24), width=40).pack(side="left", padx=(8, 2))
            text = ctk.CTkFrame(row, fg_color="transparent")
            text.pack(side="left", fill="x", expand=True, pady=6)
            ctk.CTkLabel(text, text=shorten(p["name"], 24), font=ctk.CTkFont(weight="bold"), anchor="w").pack(fill="x")
            ctk.CTkLabel(text, text=f"${p['price'] * qty:,.2f}", text_color=MUTED, anchor="w").pack(fill="x")
            danger_btn(row, "✕", lambda i=pid: c.change_qty(i, -c.cart.get(i, 0)), width=30).pack(side="right", padx=4)
            ctk.CTkButton(row, text="+", width=28, command=lambda i=pid: c.change_qty(i, 1)).pack(side="right", padx=2)
            ctk.CTkLabel(row, text=str(qty), width=26).pack(side="right")
            ctk.CTkButton(row, text="−", width=28, command=lambda i=pid: c.change_qty(i, -1)).pack(side="right", padx=2)
        self.total_label.configure(text=f"Total: ${c.cart_total():,.2f}")

    def do_checkout(self):
        ok, msg = self.controller.checkout()
        if ok:
            messagebox.showinfo("Checkout", msg, parent=self)
            self.close()
        else:
            messagebox.showwarning("Checkout", msg, parent=self)

    def close(self):
        self.controller.cart_window = None
        self.destroy()


# ============================================================
# ADMIN: PRODUCT FORM (add / edit)
# ============================================================
class ProductForm(ctk.CTkToplevel):
    def __init__(self, controller, product=None, default_category=None):
        super().__init__(controller)
        self.controller = controller
        self.product = product
        self.title("Edit Product" if product else "Add New Product")
        self.geometry("440x740")
        self.resizable(False, False)
        self.protocol("WM_DELETE_WINDOW", self.close)

        ctk.CTkLabel(self, text=self.title(), font=ctk.CTkFont(size=22, weight="bold")).pack(pady=(16, 4))

        # Buttons are packed first (at the bottom) so they stay visible; the fields scroll.
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.pack(side="bottom", fill="x", pady=(0, 10))
        green_btn(footer, "SAVE PRODUCT", self.save, width=340, height=40).pack(pady=(8, 4))
        link_btn(footer, "Cancel", self.close).pack()
        self.body = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=8)

        p = product or {}
        db = controller.db
        self.image_src = None
        self.extra_widgets = {}
        # Existing monitor/accessory details (only used while the category kind is unchanged).
        self.initial_kind = spec_kind(p.get("category")) if product else None
        self.initial_extra = {}
        if product and db.specs_available:
            try:
                self.initial_extra = db.get_extra_specs(product["id"], product["category"])
            except MySQLError:
                self.initial_extra = {}

        self.name_e = self.field("Product name", p.get("name", ""))
        cats = controller.all_categories()
        ctk.CTkLabel(self.body, text="Category", anchor="w").pack(fill="x", padx=20, pady=(8, 0))
        self.cat_menu = ctk.CTkOptionMenu(self.body, values=cats, width=340, command=self.on_category_change)
        self.cat_menu.set(p.get("category") or (default_category if default_category in cats else cats[0]))
        self.cat_menu.pack(pady=(2, 0))
        self.specs_label = ctk.CTkLabel(self.body, text="Specs", anchor="w")
        self.specs_label.pack(fill="x", padx=20, pady=(8, 0))
        self.specs_e = ctk.CTkEntry(self.body, width=340, height=36)
        self.specs_e.insert(0, p.get("specs", ""))
        self.specs_e.pack(pady=(2, 0))
        self.price_e = self.field("Price ($)", str(p.get("price", "")))
        self.rating_e = self.field("Rating (0-5)", str(p.get("rating", "4.5")))
        self.icon_e = self.field("Emoji icon", p.get("icon", "📦"))
        self.stock_e = self.field("Stock", str(p.get("stock", "10")))

        # Monitor / accessory detail fields appear here for those categories only.
        self.extra_frame = ctk.CTkFrame(self.body, fg_color="transparent")
        self.extra_frame.pack(fill="x")
        self.on_category_change(self.cat_menu.get())

        ctk.CTkLabel(self.body, text="Product image (optional)", anchor="w").pack(fill="x", padx=20, pady=(8, 0))
        img_row = ctk.CTkFrame(self.body, fg_color="transparent")
        img_row.pack(fill="x", padx=20, pady=(2, 10))
        ctk.CTkButton(img_row, text="Choose image…", width=130, command=self.choose_image).pack(side="left")
        current = find_image(p) if product else None
        self.image_label = ctk.CTkLabel(
            img_row, text=shorten(current.name, 22) if current else "none (emoji is used)", text_color=MUTED)
        self.image_label.pack(side="left", padx=8)
        self.after(150, self._front)

    def _front(self):
        if self.winfo_exists():
            self.lift()
            self.focus()

    def choose_image(self):
        path = filedialog.askopenfilename(
            parent=self, title="Choose product image",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        if path:
            self.image_src = path
            self.image_label.configure(text=shorten(Path(path).name, 22))
        self.lift()

    def field(self, label, value):
        ctk.CTkLabel(self.body, text=label, anchor="w").pack(fill="x", padx=20, pady=(8, 0))
        e = ctk.CTkEntry(self.body, width=340, height=36)
        e.insert(0, value)
        e.pack(pady=(2, 0))
        return e

    # ---------------- monitor / accessory detail fields ----------------
    def active_kind(self):
        """'monitor' / 'accessory' when the chosen category has detail tables AND they exist in the DB."""
        kind = spec_kind(self.cat_menu.get())
        return kind if kind and self.controller.db.specs_available else None

    def on_category_change(self, category):
        kind = self.active_kind()
        for w in self.extra_frame.winfo_children():
            w.destroy()
        self.extra_widgets = {}
        if not kind:
            self.specs_label.configure(text="Specs")
            return
        self.specs_label.configure(text="Specs (leave blank to auto-generate)")
        saved = self.initial_extra if kind == self.initial_kind else {}
        title = "Monitor details" if kind == "monitor" else "Accessory details"
        ctk.CTkLabel(self.extra_frame, text=title, anchor="w",
                     font=ctk.CTkFont(size=14, weight="bold")).pack(fill="x", padx=20, pady=(14, 0))
        for key, label, ftype, required, extra in SPEC_FIELDS[kind]:
            value = saved.get(key)
            if ftype == "bool":
                w = ctk.CTkSwitch(self.extra_frame, text=label)
                if value:
                    w.select()
                w.pack(anchor="w", padx=20, pady=(10, 0))
            else:
                ctk.CTkLabel(self.extra_frame, text=label + (" *" if required else ""),
                             anchor="w").pack(fill="x", padx=20, pady=(8, 0))
                if ftype == "choice":
                    w = ctk.CTkOptionMenu(self.extra_frame, values=list(extra), width=340)
                    w.set(value if value in extra else extra[0])
                else:
                    w = ctk.CTkEntry(self.extra_frame, width=340, height=36)
                    shown = f"{value:g}" if isinstance(value, float) else ("" if value is None else str(value))
                    w.insert(0, shown or extra)
                w.pack(pady=(2, 0))
            self.extra_widgets[key] = (ftype, required, label, w)

    def collect_extra(self, kind):
        """Validate and return ({column: value}, None) or (None, error message)."""
        data = {}
        for key, (ftype, required, label, w) in self.extra_widgets.items():
            clean_label = label.replace(" (optional)", "")
            if ftype == "bool":
                data[key] = 1 if w.get() else 0
                continue
            raw = w.get().strip()
            if ftype == "choice":
                data[key] = raw
                continue
            if not raw:
                if required:
                    return None, f"{clean_label} is required."
                data[key] = None
                continue
            try:
                if ftype == "text":
                    data[key] = raw
                elif ftype == "int":
                    data[key] = int(raw)
                    if data[key] <= 0:
                        raise ValueError
                elif ftype == "float":
                    data[key] = float(raw)
                    if data[key] <= 0:
                        raise ValueError
                elif ftype == "resolution":
                    norm = re.sub(r"\s+", "", raw.lower().replace("×", "x"))
                    if not re.fullmatch(r"\d+x\d+", norm):
                        raise ValueError
                    data[key] = norm
                elif ftype == "ratio":
                    norm = raw.replace(" ", "")
                    if not re.fullmatch(r"\d+(\.\d+)?:\d+(\.\d+)?", norm):
                        raise ValueError
                    data[key] = norm
            except ValueError:
                hints = {"int": "a whole number greater than 0", "float": "a number greater than 0",
                         "resolution": "like 2560x1440", "ratio": "like 16:9"}
                return None, f"{clean_label} must be {hints.get(ftype, 'valid')}."
        return data, None

    def save(self):
        c = self.controller
        name, specs, icon = self.name_e.get().strip(), self.specs_e.get().strip(), self.icon_e.get().strip()
        kind = self.active_kind()
        if not name or not icon or (not specs and not kind):
            messagebox.showerror("Invalid Input", "Name, specs, and icon are required.", parent=self)
            return
        try:
            price = float(self.price_e.get())
            if price <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Input", "Price must be a number greater than 0.", parent=self)
            return
        try:
            stock = int(self.stock_e.get())
            if stock < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Input", "Stock must be a whole number, 0 or more.", parent=self)
            return
        try:
            rating = float(self.rating_e.get())
            if not 0 <= rating <= 5:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Input", "Rating must be between 0 and 5.", parent=self)
            return

        extra = None
        if kind:
            extra, error = self.collect_extra(kind)
            if error:
                messagebox.showerror("Invalid Input", error, parent=self)
                return
            if not specs:
                specs = build_specs_summary(kind, extra)

        try:
            exclude_id = self.product["id"] if self.product else None
            if c.db.name_exists(name, exclude_id=exclude_id):
                messagebox.showerror("Duplicate", "A product with that name already exists.", parent=self)
                return
        except MySQLError as err:
            messagebox.showerror("Database Error", f"Could not reach the database:\n{err}", parent=self)
            return

        category = self.cat_menu.get()
        image_path = self.product.get("image") if self.product else None
        if self.image_src:
            try:
                IMAGE_DIR.mkdir(exist_ok=True)
                dest = IMAGE_DIR / f"{slugify(name)}{Path(self.image_src).suffix.lower()}"
                if Path(self.image_src).resolve() != dest.resolve():
                    shutil.copyfile(self.image_src, dest)
                image_path = str(dest)
            except OSError as err:
                messagebox.showerror("Image Error", f"Could not copy the image: {err}", parent=self)
                return

        try:
            if self.product:
                c.db.update_product(self.product["id"], category, name, specs, price, rating,
                                     icon, image_path, stock, extra=extra)
            else:
                c.db.add_product(category, name, specs, price, rating, icon, image_path, stock, extra=extra)
        except MySQLError as err:
            messagebox.showerror("Database Error", f"Could not save the product:\n{err}", parent=self)
            return

        c.reload_products()
        c.refresh_all()
        self.close()

    def close(self):
        self.controller.form_window = None
        self.destroy()


# ============================================================
# ADMIN DASHBOARD
# ============================================================
class AdminFrame(ctk.CTkFrame):
    def __init__(self, parent, controller):
        super().__init__(parent, corner_radius=0, fg_color=(LIGHT_BG, DARK_BG))
        self.controller = controller
        self.selected_category = "All"
        self.period = "Today"
        c = controller

        # ---- top header ----
        header = ctk.CTkFrame(self, height=64, corner_radius=0, fg_color=(LIGHT_PANEL, DARK_PANEL),
                              border_width=1, border_color=(LIGHT_BORDER, DARK_BORDER))
        header.pack(fill="x")
        header.pack_propagate(False)
        ctk.CTkLabel(header, text="NEXUS TECH STORE", font=ctk.CTkFont(size=20, weight="bold"),
                     text_color=("#182838", NEON)).pack(side="left", padx=(20, 8))
        ctk.CTkLabel(header, text=" ADMIN ", font=ctk.CTkFont(size=11, weight="bold"), corner_radius=6,
                     fg_color=GREEN, text_color=GREEN_TEXT).pack(side="left")
        self.theme_switch = ctk.CTkSwitch(header, text="", width=45, command=c.toggle_theme)
        self.theme_switch.pack(side="right", padx=(5, 15))
        danger_btn(header, "Logout", c.logout, width=65, height=34).pack(side="right", padx=4)
        ctk.CTkButton(header, text="View Store →", width=110, height=34,
                      command=lambda: c.show_frame("StoreFrame")).pack(side="right", padx=8)

        # ---- body: sidebar + main ----
        body = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        body.pack(fill="both", expand=True)
        self.sidebar = CategorySidebar(body, c, self.set_category)
        self.sidebar.pack(side="left", fill="y")
        main = ctk.CTkFrame(body, fg_color="transparent")
        main.pack(side="left", fill="both", expand=True)

        # analytics panel (top of main area)
        self.analytics = ctk.CTkFrame(main, height=250, corner_radius=16, fg_color=(LIGHT_PANEL, DARK_PANEL),
                                      border_width=1, border_color=(LIGHT_BORDER, DARK_BORDER))
        self.analytics.pack(fill="x", padx=14, pady=(12, 6))
        self.analytics.pack_propagate(False)
        top = ctk.CTkFrame(self.analytics, fg_color="transparent")
        top.pack(fill="x", padx=16, pady=(10, 0))
        self.analytics_title = ctk.CTkLabel(top, text="", font=ctk.CTkFont(size=16, weight="bold"))
        self.analytics_title.pack(side="left")
        self.period_toggle = ctk.CTkSegmentedButton(top, values=["Today", "This Week"], command=self.set_period)
        self.period_toggle.set(self.period)
        self.period_toggle.pack(side="right")
        self.chart_area = ctk.CTkFrame(self.analytics, fg_color="transparent")
        self.chart_area.pack(fill="both", expand=True, padx=12, pady=(4, 8))

        # product list header + list
        lh = ctk.CTkFrame(main, fg_color="transparent")
        lh.pack(fill="x", padx=18, pady=(6, 2))
        self.list_title = ctk.CTkLabel(lh, text="", font=ctk.CTkFont(size=18, weight="bold"))
        self.list_title.pack(side="left")
        green_btn(lh, "+ Add New Product", self.open_form, width=160, height=34).pack(side="right")
        self.list_area = ctk.CTkScrollableFrame(main, fg_color="transparent")
        self.list_area.pack(fill="both", expand=True, padx=8, pady=(0, 6))

    # ---------------- events ----------------
    def set_category(self, category):
        self.selected_category = category
        self.refresh()

    def set_period(self, period):
        self.period = period
        self.refresh_analytics()

    def open_form(self, product=None):
        c = self.controller
        w = c.form_window
        if w is not None and w.winfo_exists():
            w.lift()
            w.focus()
            return
        c.form_window = ProductForm(c, product, self.selected_category)

    def confirm_delete(self, product):
        if messagebox.askyesno("Delete Product", f"Delete '{product['name']}'? This cannot be undone."):
            self.controller.delete_product(product)

    # ---------------- refresh ----------------
    def refresh(self):
        if self.controller.dark_mode:
            self.theme_switch.select()
        else:
            self.theme_switch.deselect()
        self.sidebar.highlight(self.selected_category)
        self.refresh_analytics()
        self.refresh_list()

    def refresh_analytics(self):
        c = self.controller
        cat = self.selected_category
        scope = "Whole Store" if cat == "All" else cat
        self.analytics_title.configure(text=f"📊 Sales Analytics · {scope}")
        for w in self.chart_area.winfo_children():
            w.destroy()

        sales = c.get_sales(self.period, cat)
        if not sales:
            ctk.CTkLabel(self.chart_area, text=f"No sales recorded {self.period.lower()} for {scope}.",
                         text_color=MUTED).pack(expand=True)
            return

        units = sum(s["qty"] for s in sales)
        revenue = sum(s["qty"] * s["unit_price"] for s in sales)
        by_product = c.rank(sales, "name")
        by_cat = c.rank(sales, "category")

        kpis = ctk.CTkFrame(self.chart_area, fg_color="transparent", width=380)
        kpis.pack(side="left", fill="y", padx=(0, 10))
        kpis.grid_columnconfigure((0, 1), weight=1)
        for i, (label, value) in enumerate([
            ("UNITS SOLD", f"{units:,}"),
            ("REVENUE", f"${revenue:,.0f}"),
            ("TOP DEVICE", shorten(by_product[0][0], 17)),
            ("TOP CATEGORY", by_cat[0][0]),
        ]):
            card = ctk.CTkFrame(kpis, corner_radius=12, width=180, fg_color=(LIGHT_BG, DARK_BG))
            card.grid(row=i // 2, column=i % 2, padx=4, pady=4, sticky="nsew")
            ctk.CTkLabel(card, text=label, font=ctk.CTkFont(size=10, weight="bold"),
                         text_color=MUTED).pack(anchor="w", padx=12, pady=(10, 0))
            ctk.CTkLabel(card, text=value, font=ctk.CTkFont(size=15, weight="bold")).pack(
                anchor="w", padx=12, pady=(0, 10))

        chart = ctk.CTkFrame(self.chart_area, fg_color="transparent")
        chart.pack(side="left", fill="both", expand=True)
        ctk.CTkLabel(chart, text="Top-selling devices", font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=MUTED, anchor="w").pack(fill="x", pady=(2, 4))
        top5 = by_product[:5]
        peak = top5[0][1]
        for i, (name, sold) in enumerate(top5):
            row = ctk.CTkFrame(chart, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=f"{c.icon_for(name)} {shorten(name, 20)}", width=200, anchor="w").pack(side="left")
            bar = ctk.CTkProgressBar(row, height=12, progress_color=GREEN if i == 0 else BAR_BLUE)
            bar.set(sold / peak)
            bar.pack(side="left", fill="x", expand=True, padx=8)
            ctk.CTkLabel(row, text=f"{sold} sold", width=60, anchor="e").pack(side="left")

    def refresh_list(self):
        c = self.controller
        cat = self.selected_category
        for w in self.list_area.winfo_children():
            w.destroy()
        items = [p for p in c.products if cat == "All" or p["category"] == cat]
        self.list_title.configure(
            text=f"{'All Products' if cat == 'All' else cat}  ({len(items)})")

        for p in items:
            row = ctk.CTkFrame(self.list_area, corner_radius=10, fg_color=(LIGHT_CARD, DARK_CARD))
            row.pack(fill="x", padx=6, pady=3)
            ctk.CTkLabel(row, text=p["icon"], font=ctk.CTkFont(size=22), width=44).pack(side="left", padx=(8, 2), pady=6)
            ctk.CTkLabel(row, text=shorten(p["name"], 26), font=ctk.CTkFont(weight="bold"),
                         width=215, anchor="w").pack(side="left")
            ctk.CTkLabel(row, text=p["category"], text_color=MUTED, width=135, anchor="w").pack(side="left")
            ctk.CTkLabel(row, text=f"${p['price']:,.2f}", width=90, anchor="w").pack(side="left")
            low = p["stock"] <= 5
            ctk.CTkLabel(row, text=f"Stock: {p['stock']}", width=80, anchor="w",
                         text_color=("#c13f3f", "#ff7777") if low else MUTED).pack(side="left")
            ctk.CTkLabel(row, text=f"★ {p['rating']}", width=50, anchor="w",
                         text_color=("#c48400", "#ffbf3d")).pack(side="left")
            danger_btn(row, "Delete", lambda pr=p: self.confirm_delete(pr), width=60, height=30).pack(side="right", padx=(0, 8))
            link_btn(row, "Edit", lambda pr=p: self.open_form(pr), width=50, height=30).pack(side="right")


# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    app = NexusTechStoreApp()
    app.mainloop()
