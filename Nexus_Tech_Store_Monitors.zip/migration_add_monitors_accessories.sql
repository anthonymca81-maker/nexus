-- ============================================================
-- NEXUS TECH STORE : MIGRATION - add 'Monitors & Accessories'
--
-- NON-DESTRUCTIVE. Keeps all your current users, products, orders and sales.
-- Does NOT drop the database or any table, and is safe to run more than once.
--
-- HOW TO USE (XAMPP):
--   phpMyAdmin -> click the 'nexus_tech_store' database on the left -> Import
--   -> choose this file -> Go.   (or paste it into the SQL tab)
--
-- ADDS:
--   tables : monitor_specs, monitor_accessory_specs        (new, 1-to-1 with products)
--   data   : department 'Monitors & Accessories' with categories
--            Monitors, Monitor Arms, Display Cables, Webcams & Lights
--            + 11 sample products with specs
--   views  : v_monitor_catalog, v_accessory_catalog
-- ============================================================
USE nexus_tech_store;

-- ============================================================
-- MONITORS & ACCESSORIES : new tables
-- Both tables are 1-to-1 extensions of `products` (product_id is the PK AND a
-- foreign key), so they never duplicate or replace anything in existing tables.
-- ON DELETE CASCADE: deleting a product also removes its spec row automatically.
-- No triggers are used (see README_FIX.txt: a stock trigger caused conflicts).
-- ============================================================

-- ---------- monitor_specs: technical details for products in the 'Monitors' category ----------
CREATE TABLE IF NOT EXISTS monitor_specs (
    product_id       INT UNSIGNED  NOT NULL PRIMARY KEY,
    screen_size_in   DECIMAL(4,1)  NOT NULL,                       -- diagonal, inches (e.g. 27.0)
    resolution       VARCHAR(20)   NOT NULL,                       -- e.g. 2560x1440
    panel_type       ENUM('IPS','VA','TN','OLED','QD-OLED','Mini-LED','Other') NOT NULL DEFAULT 'IPS',
    refresh_rate_hz  SMALLINT UNSIGNED NOT NULL DEFAULT 60,
    response_time_ms DECIMAL(5,2)  NULL,                           -- e.g. 1.00 or 0.03
    aspect_ratio     VARCHAR(10)   NOT NULL DEFAULT '16:9',
    is_curved        TINYINT(1)    NOT NULL DEFAULT 0,
    hdr_support      VARCHAR(40)   NULL,
    ports            VARCHAR(200)  NULL,
    updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_mspec_product FOREIGN KEY (product_id)
        REFERENCES products(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_mspec_size    CHECK (screen_size_in > 0),
    CONSTRAINT chk_mspec_refresh CHECK (refresh_rate_hz > 0),
    CONSTRAINT chk_mspec_resp    CHECK (response_time_ms IS NULL OR response_time_ms > 0),
    CONSTRAINT chk_mspec_res     CHECK (resolution REGEXP '^[0-9]+x[0-9]+$'),
    CONSTRAINT chk_mspec_curved  CHECK (is_curved IN (0,1)),
    INDEX idx_mspec_refresh (refresh_rate_hz),
    INDEX idx_mspec_panel (panel_type)
) ENGINE=InnoDB;

-- ---------- monitor_accessory_specs: details for arms, cables, webcams, lights ----------
CREATE TABLE IF NOT EXISTS monitor_accessory_specs (
    product_id     INT UNSIGNED  NOT NULL PRIMARY KEY,
    accessory_type ENUM('arm','stand','cable','adapter','webcam','light_bar','other') NOT NULL DEFAULT 'other',
    compatibility  VARCHAR(200)  NULL,                             -- what it works with
    connector_type VARCHAR(60)   NULL,                             -- e.g. DisplayPort 1.4 (M/M)
    length_m       DECIMAL(5,2)  NULL,                             -- cables
    max_load_kg    DECIMAL(5,2)  NULL,                             -- arms / stands
    vesa_pattern   VARCHAR(40)   NULL,                             -- e.g. 75x75, 100x100
    updated_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_aspec_product FOREIGN KEY (product_id)
        REFERENCES products(id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT chk_aspec_len  CHECK (length_m IS NULL OR length_m > 0),
    CONSTRAINT chk_aspec_load CHECK (max_load_kg IS NULL OR max_load_kg > 0),
    INDEX idx_aspec_type (accessory_type)
) ENGINE=InnoDB;


-- ============================================================
-- MONITORS & ACCESSORIES : department, categories, sample products, spec rows
-- Safe to run more than once: every insert checks for an existing row by NAME first.
-- (Sample products/prices are demo data - edit them freely in the Admin panel.)
-- ============================================================

INSERT INTO departments (name)
SELECT 'Monitors & Accessories'
WHERE NOT EXISTS (SELECT 1 FROM departments WHERE name = 'Monitors & Accessories');

INSERT INTO categories (department_id, name)
SELECT d.id, v.name
FROM departments d
JOIN (SELECT 'Monitors' AS name
      UNION ALL SELECT 'Monitor Arms'
      UNION ALL SELECT 'Display Cables'
      UNION ALL SELECT 'Webcams & Lights') v
WHERE d.name = 'Monitors & Accessories'
  AND NOT EXISTS (SELECT 1 FROM categories c WHERE c.name = v.name);

INSERT INTO products (category_id, name, specs, price, rating, icon, stock)
SELECT c.id, v.name, v.specs, v.price, v.rating, v.icon, v.stock
FROM (
    SELECT 'Monitors' AS cat, 'LG UltraGear 27GP850-B' AS name, '27" • 2560x1440 • IPS • 165Hz • 1ms • HDR10' AS specs, 299.99 AS price, 4.6 AS rating, '🖥️' AS icon, 14 AS stock
    UNION ALL SELECT 'Monitors', 'Dell UltraSharp U2723QE',       '27" • 3840x2160 • IPS • 60Hz • 5ms • USB-C 90W', 579.99, 4.6, '🖥️', 10
    UNION ALL SELECT 'Monitors', 'Samsung Odyssey G9 G95C 49"',   '49" • 5120x1440 • VA • 240Hz • 1ms • Curved • HDR10+', 999.99, 4.5, '🖥️', 6
    UNION ALL SELECT 'Monitors', 'ASUS ROG Swift OLED PG27AQDM',  '26.5" • 2560x1440 • OLED • 240Hz • 0.03ms • HDR10', 899.99, 4.7, '🖥️', 8
    UNION ALL SELECT 'Monitors', 'AOC 24G2SP',                    '23.8" • 1920x1080 • IPS • 165Hz • 1ms', 139.99, 4.6, '🖥️', 25
    UNION ALL SELECT 'Monitor Arms', 'Ergotron LX Desk Monitor Arm', 'Single Arm • Up to 11.3kg • VESA 75/100 • Height Adjustable', 199.99, 4.8, '🔩', 20
    UNION ALL SELECT 'Monitor Arms', 'VIVO Dual Monitor Desk Mount', 'Dual Arm • 13"-27" • 10kg per Arm • VESA 75/100', 49.99, 4.5, '🔩', 35
    UNION ALL SELECT 'Display Cables', 'Cable Matters DisplayPort 1.4 Cable (6 ft)', 'DisplayPort 1.4 • VESA Certified • 8K/60Hz • 1.8m', 14.99, 4.7, '🔗', 80
    UNION ALL SELECT 'Display Cables', 'Belkin Ultra HD High Speed HDMI 2.1 Cable (6.6 ft)', 'HDMI 2.1 • 48Gbps • 8K/60Hz • 4K/120Hz • 2m', 29.99, 4.6, '🔗', 60
    UNION ALL SELECT 'Webcams & Lights', 'Logitech C920s HD Pro Webcam', '1080p/30fps • Dual Mics • Privacy Shutter • USB', 69.99, 4.6, '📷', 45
    UNION ALL SELECT 'Webcams & Lights', 'BenQ ScreenBar Halo Monitor Light', 'Auto-Dimming • Asymmetric Light • USB-powered • Clamp Mount', 179.00, 4.7, '💡', 18
) v
JOIN categories c ON c.name = v.cat
WHERE NOT EXISTS (SELECT 1 FROM products p WHERE p.name = v.name);

INSERT INTO monitor_specs
    (product_id, screen_size_in, resolution, panel_type, refresh_rate_hz,
     response_time_ms, aspect_ratio, is_curved, hdr_support, ports)
SELECT p.id, v.sz, v.res, v.panel, v.hz, v.resp, v.ratio, v.curved, v.hdr, v.ports
FROM (
    SELECT 'LG UltraGear 27GP850-B' AS pname, 27.0 AS sz, '2560x1440' AS res, 'IPS' AS panel, 165 AS hz, 1.00 AS resp, '16:9' AS ratio, 0 AS curved, 'HDR10' AS hdr, '2x HDMI 2.0, DisplayPort 1.4, USB hub' AS ports
    UNION ALL SELECT 'Dell UltraSharp U2723QE', 27.0, '3840x2160', 'IPS', 60, 5.00, '16:9', 0, 'DisplayHDR 400', 'HDMI, DisplayPort in/out, USB-C 90W PD, RJ45, USB hub'
    UNION ALL SELECT 'Samsung Odyssey G9 G95C 49"', 49.0, '5120x1440', 'VA', 240, 1.00, '32:9', 1, 'HDR10+', 'HDMI 2.1, DisplayPort 1.4, USB hub'
    UNION ALL SELECT 'ASUS ROG Swift OLED PG27AQDM', 26.5, '2560x1440', 'OLED', 240, 0.03, '16:9', 0, 'HDR10', 'DisplayPort 1.4, 2x HDMI 2.0, USB hub'
    UNION ALL SELECT 'AOC 24G2SP', 23.8, '1920x1080', 'IPS', 165, 1.00, '16:9', 0, NULL, '2x HDMI 2.0, DisplayPort'
) v
JOIN products p ON p.name = v.pname
WHERE NOT EXISTS (SELECT 1 FROM monitor_specs m WHERE m.product_id = p.id);

INSERT INTO monitor_accessory_specs
    (product_id, accessory_type, compatibility, connector_type, length_m, max_load_kg, vesa_pattern)
SELECT p.id, v.atype, v.compat, v.conn, v.len_m, v.load_kg, v.vesa
FROM (
    SELECT 'Ergotron LX Desk Monitor Arm' AS pname, 'arm' AS atype, 'Single monitors up to 34 inch' AS compat, 'Desk clamp / grommet' AS conn, NULL AS len_m, 11.30 AS load_kg, '75x75, 100x100' AS vesa
    UNION ALL SELECT 'VIVO Dual Monitor Desk Mount', 'arm', 'Two 13-27 inch monitors', 'Desk clamp / grommet', NULL, 10.00, '75x75, 100x100'
    UNION ALL SELECT 'Cable Matters DisplayPort 1.4 Cable (6 ft)', 'cable', 'DisplayPort 1.4 monitors, GPUs and docks', 'DisplayPort 1.4 (M/M)', 1.83, NULL, NULL
    UNION ALL SELECT 'Belkin Ultra HD High Speed HDMI 2.1 Cable (6.6 ft)', 'cable', 'HDMI 2.1 monitors, consoles and GPUs', 'HDMI 2.1 (M/M)', 2.00, NULL, NULL
    UNION ALL SELECT 'Logitech C920s HD Pro Webcam', 'webcam', 'Windows, macOS, ChromeOS; clips onto monitors', 'USB-A', NULL, NULL, NULL
    UNION ALL SELECT 'BenQ ScreenBar Halo Monitor Light', 'light_bar', 'Clamps onto flat and curved monitors', 'USB-A (5V)', NULL, NULL, NULL
) v
JOIN products p ON p.name = v.pname
WHERE NOT EXISTS (SELECT 1 FROM monitor_accessory_specs a WHERE a.product_id = p.id);


-- ============================================================
-- MONITORS & ACCESSORIES : views (CREATE OR REPLACE = safe to re-run)
-- ============================================================
CREATE OR REPLACE VIEW v_monitor_catalog AS
SELECT p.id AS product_id, p.name, p.price, p.rating, p.stock, p.icon, p.image_path,
       c.name AS category,
       m.screen_size_in, m.resolution, m.panel_type, m.refresh_rate_hz,
       m.response_time_ms, m.aspect_ratio, m.is_curved, m.hdr_support, m.ports
FROM products p
JOIN categories    c ON c.id = p.category_id
JOIN monitor_specs m ON m.product_id = p.id
WHERE p.is_active = 1;

CREATE OR REPLACE VIEW v_accessory_catalog AS
SELECT p.id AS product_id, p.name, p.price, p.rating, p.stock, p.icon, p.image_path,
       c.name AS category,
       a.accessory_type, a.compatibility, a.connector_type,
       a.length_m, a.max_load_kg, a.vesa_pattern
FROM products p
JOIN categories              c ON c.id = p.category_id
JOIN monitor_accessory_specs a ON a.product_id = p.id
WHERE p.is_active = 1;


-- Quick check
SELECT d.name AS department, c.name AS category, COUNT(p.id) AS products
FROM departments d
JOIN categories c ON c.department_id = d.id
LEFT JOIN products p ON p.category_id = c.id
WHERE d.name = 'Monitors & Accessories'
GROUP BY d.name, c.name, c.id ORDER BY c.id;
